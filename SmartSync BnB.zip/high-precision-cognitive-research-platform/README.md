# Aperture

Web-based experiment platform for cognitive science: a visual protocol builder, a high-precision browser timing engine, and anonymous session storage.

## Images

The supplied images are in `public/images/` and the logo is in `public/brand/`.
The landing page uses the local WebP files for its hero, builder, privacy, and
research illustration sections. Keep the filenames and these folders when
moving the project: Next.js serves them at `/images/...` and `/brand/...`.

## Stack

- Next.js App Router
- PostgreSQL + Drizzle ORM
- Tailwind CSS

## Run in VS Code

This app needs a real PostgreSQL database running before it will work — without
one, every API route that touches the database will fail (you'll see a
"Failed to execute 'json' on 'Response': Unexpected end of JSON input" style
error, because the server has nothing valid to send back).

### 1. Get a Postgres database

Pick ONE of these:

**Option A — install Postgres locally (Windows/Mac/Linux)**
1. Install [PostgreSQL](https://www.postgresql.org/download/) (the installer sets a password for the `postgres` user — remember it).
2. Using pgAdmin (installed alongside it) or `psql`, create a database named `app_db`.
3. Your connection string is `postgresql://postgres:<your-password>@127.0.0.1:5432/app_db`.

**Option B — free hosted Postgres (fastest, no local install)**
1. Create a free database at [neon.tech](https://neon.tech) or [supabase.com](https://supabase.com).
2. Copy the connection string it gives you (starts with `postgresql://`).

### 2. Configure the app

In the project root, copy `.env.example` to `.env`:
```
copy .env.example .env
```
Open `.env` and paste in your real connection string from step 1 (only needed
if it's different from the default local one already in the file).

### 3. Install dependencies and create the tables

```
npm install
npx drizzle-kit push
```
`drizzle-kit push` reads `src/db/schema.ts` and creates the actual tables
(researchers, experiments, sessions, responses) in your database. **This step
is required** — without it you'll get errors like `relation "experiments"
does not exist`.

### 4. Run it

```
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

### If something still fails

Check the terminal running `npm run dev` — every API route now returns a
readable `{ "error": "..." }` message instead of crashing silently, and the
real cause (e.g. `ECONNREFUSED`, meaning Postgres isn't running or reachable)
is printed there.

Demo researcher (seeded on first home-page load):

- Email: `iris.patel@aperture.lab`
- Password: `research2026`

## What to try

- Landing page live RT widget
- Sign in → lab bench → visual builder
- Publish a protocol and take it at `/run/STROOP`
- Inspect results and download the anonymous CSV
