import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

// Falls back to the same local default used by drizzle.config.json so a
// fresh checkout with a local Postgres instance works without extra setup.
// Set DATABASE_URL in a .env file to point at a different database.
const databaseUrl = process.env.DATABASE_URL || "postgresql://postgres:postgres@127.0.0.1:5432/app_db";

if (!process.env.DATABASE_URL) {
  console.warn(
    "[db] DATABASE_URL is not set — falling back to postgresql://postgres:postgres@127.0.0.1:5432/app_db. " +
      "Set DATABASE_URL in a .env file to override this."
  );
}

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool({
    connectionString: databaseUrl,
  });

if (process.env.NODE_ENV !== "production") {
  globalForDb.__arenaNextJsPostgresqlPool = pool;
}

export const db = drizzle(pool);
