import { boolean, integer, jsonb, pgTable, real, text, timestamp, uuid } from "drizzle-orm/pg-core";
import type { Demographics, ExperimentDefinition } from "@/lib/types";

export const researchers = pgTable("researchers", {
  id: uuid("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  institution: text("institution"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const authSessions = pgTable("auth_sessions", {
  id: uuid("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  researcherId: uuid("researcher_id")
    .notNull()
    .references(() => researchers.id, { onDelete: "cascade" }),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const experiments = pgTable("experiments", {
  id: uuid("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  researcherId: uuid("researcher_id")
    .notNull()
    .references(() => researchers.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull().default(""),
  status: text("status").notNull().default("draft"),
  templateKey: text("template_key"),
  definition: jsonb("definition").$type<ExperimentDefinition>().notNull(),
  irbNote: text("irb_note"),
  estimatedMinutes: integer("estimated_minutes").notNull().default(8),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  publishedAt: timestamp("published_at", { withTimezone: true }),
});

export const participantSessions = pgTable("participant_sessions", {
  id: uuid("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  experimentId: uuid("experiment_id")
    .notNull()
    .references(() => experiments.id, { onDelete: "cascade" }),
  anonymousId: text("anonymous_id").notNull(),
  status: text("status").notNull().default("in_progress"),
  consentAt: timestamp("consent_at", { withTimezone: true }),
  startedAt: timestamp("started_at", { withTimezone: true }).defaultNow().notNull(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  userAgent: text("user_agent"),
  locale: text("locale"),
  timezone: text("timezone"),
  screenWidth: integer("screen_width"),
  screenHeight: integer("screen_height"),
  refreshHz: real("refresh_hz"),
  timingQuality: text("timing_quality"),
  frameJitterMs: real("frame_jitter_ms"),
  demographics: jsonb("demographics").$type<Demographics | null>(),
});

export const trialResponses = pgTable("trial_responses", {
  id: uuid("id").primaryKey().$defaultFn(() => crypto.randomUUID()),
  sessionId: uuid("session_id")
    .notNull()
    .references(() => participantSessions.id, { onDelete: "cascade" }),
  experimentId: uuid("experiment_id")
    .notNull()
    .references(() => experiments.id, { onDelete: "cascade" }),
  blockId: text("block_id").notNull(),
  trialId: text("trial_id").notNull(),
  trialIndex: integer("trial_index").notNull(),
  stimulusLabel: text("stimulus_label"),
  condition: text("condition"),
  correctKey: text("correct_key"),
  responseKey: text("response_key"),
  isCorrect: boolean("is_correct"),
  isTimeout: boolean("is_timeout").notNull().default(false),
  rtMs: real("rt_ms"),
  scheduledOnsetMs: real("scheduled_onset_ms"),
  actualOnsetMs: real("actual_onset_ms"),
  onsetErrorMs: real("onset_error_ms"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
