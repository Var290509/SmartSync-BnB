import { NextResponse } from "next/server";

/**
 * Turns any thrown error (a Postgres connection failure, a missing table,
 * an unexpected null, etc.) into a proper JSON response instead of letting
 * Next.js return an empty/HTML error page. Without this, a failed database
 * call crashes the whole request and the frontend's `response.json()` call
 * throws "Unexpected end of JSON input" — this is what fixes that class of bug.
 */
export function apiError(err: unknown, fallback = "Something went wrong on the server.") {
  const message = err instanceof Error ? err.message : fallback;
  // eslint-disable-next-line no-console
  console.error("[api error]", err);
  return NextResponse.json({ error: message }, { status: 500 });
}
