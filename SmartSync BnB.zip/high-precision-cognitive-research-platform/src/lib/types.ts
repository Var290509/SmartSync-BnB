export type ExperimentStatus = "draft" | "published" | "paused" | "archived";
export type BlockType = "practice" | "experimental";
export type Randomization = "none" | "shuffle";
export type StimulusKind =
  | "instruction"
  | "fixation"
  | "text"
  | "stroop"
  | "flanker"
  | "gonogo"
  | "letter"
  | "shape"
  | "blank";

export interface TrialDefinition {
  id: string;
  kind: StimulusKind;
  content: string;
  color: string;
  fontSize: number;
  background: string;
  shape?: "circle" | "square" | "triangle";
  fixationMs: number;
  timeoutMs: number;
  isiMs: number;
  soaJitterMs?: [number, number];
  responseKeys: string[];
  correctKey: string | null;
  nogo?: boolean;
  congruent?: boolean;
  condition?: string;
  feedback?: boolean;
}

export interface BlockDefinition {
  id: string;
  name: string;
  type: BlockType;
  instructions: string;
  randomization: Randomization;
  repeat: number;
  trials: TrialDefinition[];
}

export interface ExperimentDefinition {
  version: 1;
  settings: {
    fullscreenRecommended: boolean;
    collectDemographics: boolean;
    interTrialInterval: number;
    background: string;
    feedbackPracticeOnly: boolean;
  };
  consent: {
    title: string;
    body: string;
  };
  instructions: string[];
  debrief: string;
  keyLegend: { key: string; meaning: string }[];
  blocks: BlockDefinition[];
}

export interface RuntimeTrial extends TrialDefinition {
  blockId: string;
  blockName: string;
  blockType: BlockType;
  trialIndex: number;
}

export interface CalibrationResult {
  refreshHz: number;
  frameJitterMs: number;
  quality: "excellent" | "good" | "fair" | "poor";
  sampleCount: number;
}

export interface Demographics {
  ageRange?: string;
  handedness?: string;
  device?: string;
}

export interface ResearcherPublic {
  id: string;
  name: string;
  email: string;
  institution: string | null;
}
