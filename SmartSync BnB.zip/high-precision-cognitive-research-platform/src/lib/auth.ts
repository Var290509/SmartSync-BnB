import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { and, eq, gt } from "drizzle-orm";
import { cookies } from "next/headers";
import { db } from "@/db";
import { authSessions, researchers } from "@/db/schema";
import type { ResearcherPublic } from "@/lib/types";

export const SESSION_COOKIE = "aperture_session";
const SESSION_DAYS = 14;

export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string) {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const actual = Buffer.from(hash, "hex");
  const incoming = scryptSync(password, salt, 64);
  if (actual.length !== incoming.length) return false;
  return timingSafeEqual(actual, incoming);
}

export function newSessionToken() {
  return randomBytes(32).toString("hex");
}

export function sessionCookieOptions(expiresAt: Date) {
  return {
    httpOnly: true as const,
    sameSite: "lax" as const,
    path: "/",
    expires: expiresAt,
    secure: process.env.NODE_ENV === "production",
  };
}

export async function createSession(researcherId: string) {
  const token = newSessionToken();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(authSessions).values({ researcherId, token, expiresAt });
  return { token, expiresAt };
}

export function toPublicResearcher(row: typeof researchers.$inferSelect): ResearcherPublic {
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    institution: row.institution,
  };
}

export async function getCurrentResearcher() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;

  const rows = await db
    .select({
      researcher: researchers,
    })
    .from(authSessions)
    .innerJoin(researchers, eq(researchers.id, authSessions.researcherId))
    .where(and(eq(authSessions.token, token), gt(authSessions.expiresAt, new Date())))
    .limit(1);

  return rows[0]?.researcher ?? null;
}

export async function requireResearcher() {
  const researcher = await getCurrentResearcher();
  if (!researcher) return null;
  return researcher;
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(authSessions).where(eq(authSessions.token, token));
  }
}
