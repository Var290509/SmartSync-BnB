import type { ExperimentDefinition, TrialDefinition } from "@/lib/types";
import { blankDefinition } from "@/lib/experiment";

export interface TemplateMeta {
  key: string;
  name: string;
  family: string;
  blurb: string;
  minutes: number;
  measures: string[];
}

const STROOP_COLORS = [
  { name: "RED", ink: "#ff5a4e", key: "d" },
  { name: "GREEN", ink: "#3dce7a", key: "f" },
  { name: "BLUE", ink: "#4d8dff", key: "j" },
  { name: "YELLOW", ink: "#f0c94a", key: "k" },
] as const;

function stroopGrid(copies: number): TrialDefinition[] {
  const trials: TrialDefinition[] = [];
  let n = 0;
  for (const word of STROOP_COLORS) {
    for (const ink of STROOP_COLORS) {
      for (let i = 0; i < copies; i += 1) {
        n += 1;
        const congruent = word.name === ink.name;
        trials.push({
          id: `stroop-${n}`,
          kind: "stroop",
          content: word.name,
          color: ink.ink,
          fontSize: 78,
          background: "#05070c",
          fixationMs: 400,
          timeoutMs: 1800,
          isiMs: 300,
          responseKeys: ["d", "f", "j", "k"],
          correctKey: ink.key,
          congruent,
          condition: congruent ? "congruent" : "incongruent",
        });
      }
    }
  }
  return trials;
}

function flankerTrials(): TrialDefinition[] {
  const patterns: Array<{ content: string; correct: "ArrowLeft" | "ArrowRight"; congruent: boolean; condition: string }> = [
    { content: "<<<<<", correct: "ArrowLeft", congruent: true, condition: "congruent" },
    { content: ">>>>>", correct: "ArrowRight", congruent: true, condition: "congruent" },
    { content: "<<><<", correct: "ArrowRight", congruent: false, condition: "incongruent" },
    { content: ">><>>", correct: "ArrowLeft", congruent: false, condition: "incongruent" },
    { content: "--<--", correct: "ArrowLeft", congruent: true, condition: "neutral" },
    { content: "-->--", correct: "ArrowRight", congruent: true, condition: "neutral" },
  ];
  const trials: TrialDefinition[] = [];
  let n = 0;
  for (const pattern of patterns) {
    for (let i = 0; i < 6; i += 1) {
      n += 1;
      trials.push({
        id: `flank-${n}`,
        kind: "flanker",
        content: pattern.content,
        color: "#f4f1ea",
        fontSize: 72,
        background: "#05070c",
        fixationMs: 350,
        timeoutMs: 1500,
        isiMs: 280,
        responseKeys: ["ArrowLeft", "ArrowRight"],
        correctKey: pattern.correct,
        congruent: pattern.congruent,
        condition: pattern.condition,
      });
    }
  }
  return trials;
}

function goNogoTrials(): TrialDefinition[] {
  const trials: TrialDefinition[] = [];
  for (let i = 0; i < 32; i += 1) {
    const nogo = i % 5 === 0;
    trials.push({
      id: `gn-${i + 1}`,
      kind: "gonogo",
      content: nogo ? "X" : "O",
      color: nogo ? "#ff5a4e" : "#3dce7a",
      fontSize: 84,
      background: "#05070c",
      shape: "circle",
      fixationMs: 300,
      timeoutMs: nogo ? 600 : 900,
      isiMs: 400,
      responseKeys: [" "],
      correctKey: nogo ? null : " ",
      nogo,
      condition: nogo ? "nogo" : "go",
    });
  }
  return trials;
}

function srtTrials(): TrialDefinition[] {
  return Array.from({ length: 20 }, (_, i) => ({
    id: `srt-${i + 1}`,
    kind: "shape" as const,
    content: "",
    color: "#3ee0c5",
    fontSize: 16,
    background: "#05070c",
    shape: "circle" as const,
    fixationMs: 250,
    timeoutMs: 1500,
    isiMs: 400,
    soaJitterMs: [400, 1600] as [number, number],
    responseKeys: [" "],
    correctKey: " ",
    condition: "detection",
  }));
}

function nbackTrials(): TrialDefinition[] {
  const letters = ["B", "C", "D", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T"];
  const sequence: string[] = [];
  const matches: boolean[] = [];
  for (let i = 0; i < 30; i += 1) {
    if (i >= 2 && Math.random() < 0.3) {
      sequence.push(sequence[i - 2]);
      matches.push(true);
    } else {
      let letter = letters[Math.floor(Math.random() * letters.length)];
      while (i >= 2 && letter === sequence[i - 2]) {
        letter = letters[Math.floor(Math.random() * letters.length)];
      }
      sequence.push(letter);
      matches.push(false);
    }
  }
  return sequence.map((letter, i) => ({
    id: `nb-${i + 1}`,
    kind: "letter" as const,
    content: letter,
    color: "#f4f1ea",
    fontSize: 86,
    background: "#05070c",
    fixationMs: 0,
    timeoutMs: 1500,
    isiMs: 500,
    responseKeys: [" "],
    correctKey: matches[i] ? " " : null,
    nogo: !matches[i],
    condition: matches[i] ? "target" : "nontarget",
  }));
}

function lexicalTrials(): TrialDefinition[] {
  const words = ["TABLE", "GARDEN", "WINDOW", "PLANET", "SILVER", "MOTHER", "FOREST", "BRIDGE", "ORANGE", "CASTLE"];
  const nonwords = ["BLINT", "GARTEN", "WONPED", "PLONAK", "SILVET", "MOTHOR", "FORENT", "BRIDEN", "ORUNGE", "CISTLE"];
  const trials: TrialDefinition[] = [];
  words.forEach((word, i) => {
    trials.push({
      id: `lex-w-${i + 1}`,
      kind: "text",
      content: word,
      color: "#f4f1ea",
      fontSize: 64,
      background: "#05070c",
      fixationMs: 400,
      timeoutMs: 1800,
      isiMs: 300,
      responseKeys: ["f", "j"],
      correctKey: "j",
      condition: "word",
    });
  });
  nonwords.forEach((word, i) => {
    trials.push({
      id: `lex-n-${i + 1}`,
      kind: "text",
      content: word,
      color: "#f4f1ea",
      fontSize: 64,
      background: "#05070c",
      fixationMs: 400,
      timeoutMs: 1800,
      isiMs: 300,
      responseKeys: ["f", "j"],
      correctKey: "f",
      condition: "nonword",
    });
  });
  return trials;
}

export const TEMPLATES: Record<string, { meta: TemplateMeta; build: () => ExperimentDefinition }> = {
  stroop: {
    meta: {
      key: "stroop",
      name: "Color–word Stroop",
      family: "Attention",
      blurb: "Name the ink colour, not the word. Classic interference with congruent and incongruent trials.",
      minutes: 7,
      measures: ["RT", "accuracy", "interference cost"],
    },
    build: () => ({
      version: 1,
      settings: {
        fullscreenRecommended: true,
        collectDemographics: true,
        interTrialInterval: 250,
        background: "#05070c",
        feedbackPracticeOnly: true,
      },
      consent: {
        title: "Color–word Stroop — consent",
        body: "This study measures how automatically reading a word interferes with naming its ink colour. You will press keys to indicate colour. Data are stored under an anonymous code only. You may withdraw at any time with Escape. Approximate duration: 7 minutes.",
      },
      instructions: [
        "You will see colour words (RED, GREEN, BLUE, YELLOW) printed in different ink colours.",
        "Ignore the word. Respond to the INK colour as quickly as you can without sacrificing accuracy.",
        "Keys: D = red, F = green, J = blue, K = yellow.",
        "A short practice block with feedback comes first.",
      ],
      debrief:
        "In the Stroop task, people are typically slower and less accurate on incongruent trials (e.g. the word BLUE in red ink). That interference cost is a classic marker of attentional control. Thank you for contributing an anonymous session.",
      keyLegend: [
        { key: "d", meaning: "Red" },
        { key: "f", meaning: "Green" },
        { key: "j", meaning: "Blue" },
        { key: "k", meaning: "Yellow" },
      ],
      blocks: [
        {
          id: "practice",
          name: "Practice",
          type: "practice",
          instructions: "Practice: respond to ink colour. Feedback will appear after each trial.",
          randomization: "shuffle",
          repeat: 1,
          trials: stroopGrid(1).slice(0, 8).map((trial, i) => ({ ...trial, id: `prac-${i + 1}`, feedback: true })),
        },
        {
          id: "experimental",
          name: "Experimental",
          type: "experimental",
          instructions: "Main block. No feedback. Stay focused on the ink colour.",
          randomization: "shuffle",
          repeat: 1,
          trials: stroopGrid(2),
        },
      ],
    }),
  },
  flanker: {
    meta: {
      key: "flanker",
      name: "Eriksen flanker",
      family: "Selective attention",
      blurb: "Report the central arrow while ignoring flanking arrows. Congruent, incongruent, and neutral.",
      minutes: 6,
      measures: ["RT", "accuracy", "flanker effect"],
    },
    build: () => ({
      version: 1,
      settings: {
        fullscreenRecommended: true,
        collectDemographics: true,
        interTrialInterval: 240,
        background: "#05070c",
        feedbackPracticeOnly: true,
      },
      consent: {
        title: "Flanker task — consent",
        body: "This study measures selective attention: how surrounding symbols affect responses to a central target. Responses are anonymous. Withdraw any time with Escape. About 6 minutes.",
      },
      instructions: [
        "A row of arrows will appear. Attend only to the CENTER arrow.",
        "Press ← if the center arrow points left, → if it points right.",
        "Ignore the flanking arrows. They may agree or conflict with the center.",
      ],
      debrief:
        "The flanker effect is the RT cost of incongruent vs congruent surroundings — a widely used index of conflict monitoring. Thank you.",
      keyLegend: [
        { key: "ArrowLeft", meaning: "Center left" },
        { key: "ArrowRight", meaning: "Center right" },
      ],
      blocks: [
        {
          id: "practice",
          name: "Practice",
          type: "practice",
          instructions: "Practice with feedback. Respond to the center arrow only.",
          randomization: "shuffle",
          repeat: 1,
          trials: flankerTrials().slice(0, 8).map((trial, i) => ({ ...trial, id: `fp-${i + 1}`, feedback: true })),
        },
        {
          id: "experimental",
          name: "Experimental",
          type: "experimental",
          instructions: "Main block. Respond to the center arrow.",
          randomization: "shuffle",
          repeat: 1,
          trials: flankerTrials(),
        },
      ],
    }),
  },
  gonogo: {
    meta: {
      key: "gonogo",
      name: "Go / No-Go",
      family: "Inhibition",
      blurb: "Press space for Go signals and withhold for No-Go. Measures response inhibition and false alarms.",
      minutes: 5,
      measures: ["RT", "hits", "false alarms"],
    },
    build: () => ({
      version: 1,
      settings: {
        fullscreenRecommended: true,
        collectDemographics: true,
        interTrialInterval: 200,
        background: "#05070c",
        feedbackPracticeOnly: true,
      },
      consent: {
        title: "Go / No-Go — consent",
        body: "This task measures the ability to withhold a prepared response. Anonymous data only. Escape to withdraw. About 5 minutes.",
      },
      instructions: [
        "A circle will appear in the centre of the screen.",
        "If it is GREEN (O), press Space as quickly as you can.",
        "If it is RED (X), do not press anything.",
        "Go trials are more common than No-Go trials.",
      ],
      debrief:
        "Go/No-Go tasks index inhibitory control. False alarms on No-Go trials and slow hits on Go trials are the primary outcomes. Thank you.",
      keyLegend: [{ key: " ", meaning: "Go (press) / No-Go (withhold)" }],
      blocks: [
        {
          id: "experimental",
          name: "Experimental",
          type: "experimental",
          instructions: "Green = Go (Space). Red = No-Go (withhold).",
          randomization: "shuffle",
          repeat: 1,
          trials: goNogoTrials(),
        },
      ],
    }),
  },
  srt: {
    meta: {
      key: "srt",
      name: "Simple detection RT",
      family: "Psychomotor",
      blurb: "Press space the instant a circle appears after a jittered delay. Pure detection latency.",
      minutes: 4,
      measures: ["RT", "anticipations", "lapses"],
    },
    build: () => ({
      version: 1,
      settings: {
        fullscreenRecommended: true,
        collectDemographics: false,
        interTrialInterval: 200,
        background: "#05070c",
        feedbackPracticeOnly: false,
      },
      consent: {
        title: "Simple reaction time — consent",
        body: "This study records how quickly you can detect a visual onset. Anonymous. Escape to withdraw. About 4 minutes.",
      },
      instructions: [
        "Keep your eyes on the centre. A teal circle will appear after a variable delay.",
        "Press Space as soon as you see it — not before.",
        "If you press too early the trial is marked as an anticipation.",
      ],
      debrief: "Simple RT is a baseline psychomotor measure and a useful timing-engine calibration task. Thank you.",
      keyLegend: [{ key: " ", meaning: "Stimulus detected" }],
      blocks: [
        {
          id: "experimental",
          name: "Detection",
          type: "experimental",
          instructions: "Press Space the moment the circle appears.",
          randomization: "none",
          repeat: 1,
          trials: srtTrials(),
        },
      ],
    }),
  },
  nback: {
    meta: {
      key: "nback",
      name: "2-back working memory",
      family: "Working memory",
      blurb: "Press space when the current letter matches the letter from two trials ago.",
      minutes: 8,
      measures: ["hits", "false alarms", "RT"],
    },
    build: () => ({
      version: 1,
      settings: {
        fullscreenRecommended: true,
        collectDemographics: true,
        interTrialInterval: 0,
        background: "#05070c",
        feedbackPracticeOnly: true,
      },
      consent: {
        title: "2-back — consent",
        body: "This working-memory task asks you to detect letters that match the item two trials back. Anonymous. Escape to withdraw. About 8 minutes.",
      },
      instructions: [
        "Letters will appear one at a time.",
        "Press Space if the letter is the same as the one from TWO trials ago.",
        "Otherwise do nothing and wait for the next letter.",
      ],
      debrief: "N-back performance (hits vs false alarms) is a standard online probe of working-memory updating. Thank you.",
      keyLegend: [{ key: " ", meaning: "Match (2-back)" }],
      blocks: [
        {
          id: "experimental",
          name: "2-back",
          type: "experimental",
          instructions: "Press Space only on 2-back matches.",
          randomization: "none",
          repeat: 1,
          trials: nbackTrials(),
        },
      ],
    }),
  },
  lexical: {
    meta: {
      key: "lexical",
      name: "Lexical decision",
      family: "Psycholinguistics",
      blurb: "Decide whether a letter string is a real English word. J = word, F = nonword.",
      minutes: 6,
      measures: ["RT", "accuracy", "word advantage"],
    },
    build: () => ({
      version: 1,
      settings: {
        fullscreenRecommended: true,
        collectDemographics: true,
        interTrialInterval: 250,
        background: "#05070c",
        feedbackPracticeOnly: true,
      },
      consent: {
        title: "Lexical decision — consent",
        body: "You will judge whether letter strings are English words. Anonymous. Escape to withdraw. About 6 minutes.",
      },
      instructions: [
        "A letter string will appear after a fixation cross.",
        "Press J if it is a real English word.",
        "Press F if it is not a word.",
        "Respond quickly but accurately.",
      ],
      debrief: "Lexical decision times typically show a word advantage over matched nonwords. Thank you.",
      keyLegend: [
        { key: "f", meaning: "Nonword" },
        { key: "j", meaning: "Word" },
      ],
      blocks: [
        {
          id: "experimental",
          name: "Lexical decision",
          type: "experimental",
          instructions: "J = word, F = nonword.",
          randomization: "shuffle",
          repeat: 1,
          trials: lexicalTrials(),
        },
      ],
    }),
  },
  custom: {
    meta: {
      key: "custom",
      name: "Blank canvas",
      family: "Custom",
      blurb: "Start from a minimal two-trial choice-RT skeleton and design your own logic in the builder.",
      minutes: 5,
      measures: ["RT", "accuracy"],
    },
    build: () => blankDefinition(),
  },
};

export const TEMPLATE_LIST = Object.values(TEMPLATES).map((entry) => entry.meta);

export function buildTemplate(key: string): ExperimentDefinition {
  return (TEMPLATES[key] ?? TEMPLATES.custom).build();
}
