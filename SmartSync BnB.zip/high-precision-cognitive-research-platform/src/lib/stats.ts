import { mean, median, stddev } from "@/lib/utils";

export interface TrialRow {
  condition: string | null;
  isCorrect: boolean | null;
  isTimeout: boolean;
  rtMs: number | null;
  onsetErrorMs: number | null;
  blockId: string;
}

export function summarizeTrials(rows: TrialRow[]) {
  const completed = rows.filter((row) => !row.isTimeout && row.rtMs != null && row.rtMs > 80);
  const rts = completed.map((row) => row.rtMs as number);
  const correct = rows.filter((row) => row.isCorrect === true).length;
  const judged = rows.filter((row) => row.isCorrect != null).length;
  const timeouts = rows.filter((row) => row.isTimeout).length;
  const onset = rows.map((row) => row.onsetErrorMs).filter((value): value is number => value != null);

  const byCondition: Record<string, { n: number; meanRt: number; medianRt: number; accuracy: number }> = {};
  for (const row of rows) {
    const key = row.condition || "unspecified";
    if (!byCondition[key]) {
      byCondition[key] = { n: 0, meanRt: 0, medianRt: 0, accuracy: 0 };
    }
    byCondition[key].n += 1;
  }
  for (const key of Object.keys(byCondition)) {
    const subset = rows.filter((row) => (row.condition || "unspecified") === key);
    const subsetRts = subset
      .filter((row) => !row.isTimeout && row.rtMs != null && row.rtMs > 80)
      .map((row) => row.rtMs as number);
    const subsetJudged = subset.filter((row) => row.isCorrect != null);
    const subsetCorrect = subsetJudged.filter((row) => row.isCorrect).length;
    byCondition[key] = {
      n: subset.length,
      meanRt: mean(subsetRts),
      medianRt: median(subsetRts),
      accuracy: subsetJudged.length ? subsetCorrect / subsetJudged.length : 0,
    };
  }

  const histogram = histogramBins(rts, 12);

  return {
    nTrials: rows.length,
    nValidRt: rts.length,
    meanRt: mean(rts),
    medianRt: median(rts),
    sdRt: stddev(rts),
    accuracy: judged ? correct / judged : 0,
    timeoutRate: rows.length ? timeouts / rows.length : 0,
    meanOnsetError: mean(onset.map((value) => Math.abs(value))),
    byCondition,
    histogram,
  };
}

export function histogramBins(values: number[], bins: number) {
  if (values.length === 0) {
    return Array.from({ length: bins }, (_, i) => ({ start: i * 100, end: (i + 1) * 100, count: 0 }));
  }
  const min = Math.min(...values);
  const max = Math.max(...values);
  const width = Math.max(20, (max - min) / bins || 50);
  const start = Math.floor(min / 10) * 10;
  return Array.from({ length: bins }, (_, i) => {
    const a = start + i * width;
    const b = a + width;
    return {
      start: a,
      end: b,
      count: values.filter((value) => value >= a && (i === bins - 1 ? value <= b : value < b)).length,
    };
  });
}
