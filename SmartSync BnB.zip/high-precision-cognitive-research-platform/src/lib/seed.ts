import { eq } from "drizzle-orm";
import { db } from "@/db";
import { experiments, participantSessions, researchers, trialResponses } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { estimatedMinutes } from "@/lib/experiment";
import { buildTemplate } from "@/lib/templates";

export async function ensureDemoSeed() {
  try {
    await seedUnsafe();
  } catch {
    return;
  }
}

async function seedUnsafe() {
  const existing = await db
    .select({ id: researchers.id })
    .from(researchers)
    .where(eq(researchers.email, "iris.patel@aperture.lab"))
    .limit(1);
  if (existing[0]) return;

  const [researcher] = await db
    .insert(researchers)
    .values({
      name: "Dr. Iris Patel",
      email: "iris.patel@aperture.lab",
      institution: "Aperture Methods Lab",
      passwordHash: hashPassword("research2026"),
    })
    .returning();

  const stroopDef = buildTemplate("stroop");
  const flankerDef = buildTemplate("flanker");
  const srtDef = buildTemplate("srt");

  const [stroop] = await db
    .insert(experiments)
    .values({
      researcherId: researcher.id,
      title: "Color–word Stroop (open sample)",
      slug: "STROOP",
      description: "Name the ink, ignore the word. Canonical attentional control protocol, recruiting on the public board.",
      status: "published",
      templateKey: "stroop",
      definition: stroopDef,
      irbNote: "Exempt behavioural protocol · AML-2026-04",
      estimatedMinutes: estimatedMinutes(stroopDef),
      publishedAt: new Date(),
    })
    .returning();

  await db.insert(experiments).values([
    {
      researcherId: researcher.id,
      title: "Eriksen flanker (open sample)",
      slug: "FLNKR2",
      description: "Report the central arrow. Congruent, incongruent, and neutral surroundings.",
      status: "published",
      templateKey: "flanker",
      definition: flankerDef,
      irbNote: "Exempt behavioural protocol · AML-2026-05",
      estimatedMinutes: estimatedMinutes(flankerDef),
      publishedAt: new Date(),
    },
    {
      researcherId: researcher.id,
      title: "Simple detection RT (draft)",
      slug: "DETRT1",
      description: "Press space at visual onset after jittered delay. Kept as a draft for calibration checks.",
      status: "draft",
      templateKey: "srt",
      definition: srtDef,
      irbNote: "Internal timing QA",
      estimatedMinutes: estimatedMinutes(srtDef),
    },
  ]);

  const qualities = ["excellent", "good", "good", "excellent", "fair", "good", "excellent", "good"] as const;
  for (let i = 0; i < 8; i += 1) {
    const [session] = await db
      .insert(participantSessions)
      .values({
        experimentId: stroop.id,
        anonymousId: `P-A${(i + 10).toString(16).toUpperCase()}F${i + 2}`,
        status: i === 7 ? "withdrawn" : "completed",
        consentAt: new Date(Date.now() - (8 - i) * 3600_000),
        startedAt: new Date(Date.now() - (8 - i) * 3600_000),
        completedAt: i === 7 ? null : new Date(Date.now() - (8 - i) * 3600_000 + 420_000),
        locale: "en-US",
        timezone: "America/New_York",
        screenWidth: 1440,
        screenHeight: 900,
        refreshHz: i === 4 ? 59.9 : 60.0,
        timingQuality: qualities[i],
        frameJitterMs: i === 4 ? 4.8 : 0.7 + i * 0.08,
        demographics: { ageRange: i % 2 ? "25–34" : "18–24", handedness: "Right" },
      })
      .returning();

    if (i === 7) continue;

    const rows = Array.from({ length: 24 }, (_, trialIndex) => {
      const congruent = trialIndex % 3 !== 2;
      const correct = trialIndex % 11 !== 0;
      const rt = (congruent ? 510 : 655) + ((trialIndex * 13 + i * 17) % 90) + i * 6;
      return {
        sessionId: session.id,
        experimentId: stroop.id,
        blockId: "experimental",
        trialId: `seed-${trialIndex + 1}`,
        trialIndex,
        stimulusLabel: congruent ? "RED" : "BLUE",
        condition: congruent ? "congruent" : "incongruent",
        correctKey: "d",
        responseKey: correct ? "d" : "f",
        isCorrect: correct,
        isTimeout: false,
        rtMs: rt,
        scheduledOnsetMs: 400,
        actualOnsetMs: 401.2 + (trialIndex % 5) * 0.3,
        onsetErrorMs: 1.2 + (trialIndex % 5) * 0.3,
      };
    });
    await db.insert(trialResponses).values(rows);
  }
}
