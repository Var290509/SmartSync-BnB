import type { CalibrationResult } from "@/lib/types";
import { median, stddev } from "@/lib/utils";

export async function calibrateDisplay(durationMs = 1200): Promise<CalibrationResult> {
  const intervals: number[] = [];
  await new Promise<void>((resolve) => {
    let last = 0;
    const start = performance.now();
    const tick = (stamp: number) => {
      if (last) intervals.push(stamp - last);
      last = stamp;
      if (performance.now() - start < durationMs) requestAnimationFrame(tick);
      else resolve();
    };
    requestAnimationFrame(tick);
  });
  const period = median(intervals);
  const refreshHz = period > 0 ? 1000 / period : 60;
  const frameJitterMs = stddev(intervals);
  const quality: CalibrationResult["quality"] =
    frameJitterMs < 1.2 ? "excellent" : frameJitterMs < 3 ? "good" : frameJitterMs < 8 ? "fair" : "poor";
  return { refreshHz, frameJitterMs, quality, sampleCount: intervals.length };
}

export function waitAnimationFrames(ms: number) {
  const start = performance.now();
  return new Promise<void>((resolve) => {
    const tick = () => {
      if (performance.now() - start >= ms) resolve();
      else requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
}

export function nextFrame() {
  return new Promise<number>((resolve) => {
    requestAnimationFrame((stamp) => resolve(stamp));
  });
}

export async function presentOnVsync<T>(render: () => T) {
  await nextFrame();
  const scheduled = performance.now();
  const value = render();
  const actual = performance.now();
  return { value, scheduled, actual, onsetError: actual - scheduled };
}
