import type { ExperimentDefinition, RuntimeTrial, TrialDefinition } from "@/lib/types";
import { publicCode, shuffle } from "@/lib/utils";

export function blankTrial(partial?: Partial<TrialDefinition>): TrialDefinition {
  return {
    id: `t-${publicCode(5).toLowerCase()}`,
    kind: "text",
    content: "+",
    color: "#f4f1ea",
    fontSize: 64,
    background: "#05070c",
    fixationMs: 400,
    timeoutMs: 2000,
    isiMs: 300,
    responseKeys: [" "],
    correctKey: " ",
    condition: "default",
    ...partial,
  };
}

export function blankBlock(): ExperimentDefinition["blocks"][number] {
  return {
    id: `b-${publicCode(5).toLowerCase()}`,
    name: "Experimental block",
    type: "experimental",
    instructions: "Respond as quickly and accurately as you can.",
    randomization: "shuffle",
    repeat: 1,
    trials: [
      blankTrial({ content: "LEFT", correctKey: "ArrowLeft", responseKeys: ["ArrowLeft", "ArrowRight"], condition: "left" }),
      blankTrial({ content: "RIGHT", correctKey: "ArrowRight", responseKeys: ["ArrowLeft", "ArrowRight"], condition: "right" }),
    ],
  };
}

export function blankDefinition(): ExperimentDefinition {
  return {
    version: 1,
    settings: {
      fullscreenRecommended: true,
      collectDemographics: true,
      interTrialInterval: 250,
      background: "#05070c",
      feedbackPracticeOnly: true,
    },
    consent: {
      title: "Informed consent",
      body: "You are invited to take part in a behavioural experiment. Your responses are stored under an anonymous participant code. No name, email, or IP address is collected. You may withdraw at any time by pressing Escape.",
    },
    instructions: [
      "Please sit a comfortable distance from the screen and use a physical keyboard.",
      "A fixation cross will appear before each trial. Then a stimulus will appear.",
      "Respond according to the key mapping. Speed and accuracy both matter.",
    ],
    debrief: "Thank you. Your anonymous session has been stored. You may close this window.",
    keyLegend: [
      { key: "ArrowLeft", meaning: "Left" },
      { key: "ArrowRight", meaning: "Right" },
    ],
    blocks: [blankBlock()],
  };
}

export function expandTrials(definition: ExperimentDefinition): RuntimeTrial[] {
  const runtime: RuntimeTrial[] = [];
  for (const block of definition.blocks) {
    const repeats = Math.max(1, block.repeat || 1);
    for (let round = 0; round < repeats; round += 1) {
      const source = block.randomization === "shuffle" ? shuffle(block.trials) : [...block.trials];
      for (const trial of source) {
        runtime.push({
          ...trial,
          blockId: block.id,
          blockName: block.name,
          blockType: block.type,
          trialIndex: runtime.length,
        });
      }
    }
  }
  return runtime;
}

export function countTrials(definition: ExperimentDefinition) {
  return definition.blocks.reduce((sum, block) => sum + block.trials.length * Math.max(1, block.repeat || 1), 0);
}

export function estimatedMinutes(definition: ExperimentDefinition) {
  const trials = expandTrials(definition);
  const ms = trials.reduce((sum, trial) => sum + trial.fixationMs + Math.min(trial.timeoutMs, 800) + trial.isiMs, 0);
  return Math.max(3, Math.round(ms / 60000) + 2);
}
