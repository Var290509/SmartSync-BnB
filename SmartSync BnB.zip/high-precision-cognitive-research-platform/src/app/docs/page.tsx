import { getCurrentResearcher, toPublicResearcher } from "@/lib/auth";
import { Footer, MarketingNav } from "@/components/nav";

export const dynamic = "force-dynamic";

export default async function DocsPage() {
  const researcher = await getCurrentResearcher();
  return (
    <div className="min-h-screen bg-ink text-paper">
      <MarketingNav researcher={researcher ? toPublicResearcher(researcher) : null} />
      <article className="mx-auto max-w-3xl px-6 py-16">
        <p className="font-mono text-xs uppercase tracking-[0.22em] text-teal">Methods</p>
        <h1 className="mt-3 font-serif text-5xl">How the timing engine actually works.</h1>
        <div className="mt-8 space-y-8 text-mist leading-relaxed">
          <section>
            <h2 className="font-serif text-2xl text-paper">Calibration</h2>
            <p className="mt-2">
              Before trial one, Aperture samples animation-frame intervals for about a second, takes the median as a
              frame period, and reports estimated refresh (Hz) plus jitter (standard deviation). Sessions are graded
              excellent, good, fair, or poor.
            </p>
          </section>
          <section>
            <h2 className="font-serif text-2xl text-paper">Presentation</h2>
            <p className="mt-2">
              Inter-stimulus delays busy-wait on animation frames until the remaining time is within one frame, then
              reveal the stimulus inside <span className="font-mono text-teal">requestAnimationFrame</span>. We store
              scheduled onset, actual onset, and the difference (onset error).
            </p>
          </section>
          <section>
            <h2 className="font-serif text-2xl text-paper">Response</h2>
            <p className="mt-2">
              Keydowns are stamped with <span className="font-mono text-teal">performance.now()</span> relative to
              actual onset. Anticipations (responses during the wait) and timeouts are flagged rather than coerced into
              a reaction time.
            </p>
          </section>
          <section>
            <h2 className="font-serif text-2xl text-paper">What we cannot promise</h2>
            <p className="mt-2">
              A commodity laptop is not a CRT photodiode rig. OS scheduling, browser compositing, and variable refresh
              displays add noise. Aperture makes that noise visible so you can exclude poor-quality sessions instead of
              pretending it is zero.
            </p>
          </section>
        </div>
      </article>
      <Footer />
    </div>
  );
}
