import Link from "next/link";
import { redirect } from "next/navigation";
import { LoginForm } from "@/components/auth-forms";
import { Wordmark } from "@/components/brand";
import { getCurrentResearcher } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  const researcher = await getCurrentResearcher();
  if (researcher) redirect("/dashboard");

  return (
    <div className="app-shell grid min-h-screen md:grid-cols-2">
      <div className="hidden bg-ink p-10 text-paper md:flex md:flex-col md:justify-between">
        <Wordmark />
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.22em] text-teal">Researcher access</p>
          <h1 className="mt-4 font-serif text-5xl leading-tight">The bench is on the other side of this door.</h1>
        </div>
        <p className="text-sm text-mist">Demo lab: iris.patel@aperture.lab · research2026</p>
      </div>
      <div className="flex items-center justify-center px-6 py-16">
        <div className="w-full max-w-md">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-teal-2">Sign in</p>
          <h2 className="mt-2 font-serif text-4xl">Welcome back.</h2>
          <p className="mt-3 text-sm text-ink/60">Use your researcher credentials. Demo fields are prefilled.</p>
          <div className="mt-8">
            <LoginForm />
          </div>
          <p className="mt-6 text-sm text-ink/60">
            No account?{" "}
            <Link href="/register" className="text-ink underline">
              Open a lab
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
