import Link from "next/link";
import { redirect } from "next/navigation";
import { RegisterForm } from "@/components/auth-forms";
import { Wordmark } from "@/components/brand";
import { getCurrentResearcher } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function RegisterPage() {
  const researcher = await getCurrentResearcher();
  if (researcher) redirect("/dashboard");

  return (
    <div className="app-shell grid min-h-screen md:grid-cols-2">
      <div className="hidden bg-ink p-10 text-paper md:flex md:flex-col md:justify-between">
        <Wordmark />
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.22em] text-gold">New lab</p>
          <h1 className="mt-4 font-serif text-5xl leading-tight">Stand up a protocol before lunch.</h1>
        </div>
        <p className="text-sm text-mist">Anonymous participant codes. Consent first. CSV when you are ready.</p>
      </div>
      <div className="flex items-center justify-center px-6 py-16">
        <div className="w-full max-w-md">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-teal-2">Create account</p>
          <h2 className="mt-2 font-serif text-4xl">Researcher signup.</h2>
          <div className="mt-8">
            <RegisterForm />
          </div>
          <p className="mt-6 text-sm text-ink/60">
            Already registered?{" "}
            <Link href="/login" className="text-ink underline">
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
