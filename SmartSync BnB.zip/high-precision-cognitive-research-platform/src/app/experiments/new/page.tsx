import { redirect } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { NewExperimentForm } from "@/components/new-experiment-form";
import { getCurrentResearcher, toPublicResearcher } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function NewExperimentPage() {
  const researcher = await getCurrentResearcher();
  if (!researcher) redirect("/login");

  return (
    <AppShell researcher={toPublicResearcher(researcher)}>
      <NewExperimentForm />
    </AppShell>
  );
}
