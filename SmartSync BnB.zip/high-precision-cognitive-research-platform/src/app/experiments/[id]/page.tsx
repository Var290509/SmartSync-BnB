import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { experiments, participantSessions } from "@/db/schema";
import { AppShell } from "@/components/app-shell";
import { ExperimentActions } from "@/components/experiment-actions";
import { getCurrentResearcher, toPublicResearcher } from "@/lib/auth";
import { countTrials } from "@/lib/experiment";

export const dynamic = "force-dynamic";

export default async function ExperimentPage({ params }: { params: Promise<{ id: string }> }) {
  const researcher = await getCurrentResearcher();
  if (!researcher) redirect("/login");
  const { id } = await params;
  const [experiment] = await db
    .select()
    .from(experiments)
    .where(and(eq(experiments.id, id), eq(experiments.researcherId, researcher.id)))
    .limit(1);
  if (!experiment) notFound();

  const sessions = await db
    .select()
    .from(participantSessions)
    .where(eq(participantSessions.experimentId, experiment.id));

  const completed = sessions.filter((row) => row.status === "completed").length;
  const withdrawn = sessions.filter((row) => row.status === "withdrawn").length;

  return (
    <AppShell researcher={toPublicResearcher(researcher)}>
      <p className="font-mono text-xs uppercase tracking-[0.2em] text-teal-2">{experiment.slug}</p>
      <h1 className="mt-2 font-serif text-5xl">{experiment.title}</h1>
      <p className="mt-3 max-w-2xl text-ink/60">{experiment.description}</p>
      <div className="mt-6 flex flex-wrap gap-2">
        <Link href={`/experiments/${experiment.id}/builder`} className="rounded-full bg-ink px-4 py-2 text-sm text-paper">
          Visual builder
        </Link>
        <Link href={`/experiments/${experiment.id}/results`} className="rounded-full border border-ink/10 px-4 py-2 text-sm">
          Results
        </Link>
        <Link href={`/run/${experiment.slug}?preview=1`} className="rounded-full border border-ink/10 px-4 py-2 text-sm">
          Preview
        </Link>
      </div>

      <div className="mt-10 grid gap-4 md:grid-cols-4">
        {[
          ["Status", experiment.status],
          ["Trials", String(countTrials(experiment.definition))],
          ["Completed", String(completed)],
          ["Withdrawn", String(withdrawn)],
        ].map(([label, value]) => (
          <div key={label} className="rounded-3xl bg-white p-5">
            <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink/40">{label}</p>
            <p className="mt-2 font-serif text-3xl capitalize">{value}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <section className="rounded-[28px] bg-white p-6">
          <h2 className="font-serif text-2xl">Recruitment link</h2>
          <p className="mt-2 text-sm text-ink/55">
            Share this public URL once the protocol is published. Participants never see your account.
          </p>
          <p className="mt-4 break-all rounded-2xl bg-ink px-4 py-3 font-mono text-sm text-teal">
            /run/{experiment.slug}
          </p>
          <ExperimentActions id={experiment.id} status={experiment.status} slug={experiment.slug} />
        </section>
        <section className="rounded-[28px] bg-white p-6">
          <h2 className="font-serif text-2xl">Ethics</h2>
          <p className="mt-2 text-sm text-ink/60">{experiment.irbNote || "No IRB note attached yet."}</p>
          <p className="mt-4 text-sm leading-relaxed text-ink/55">{experiment.definition.consent.body}</p>
          <div className="mt-5 space-y-2">
            {experiment.definition.blocks.map((block) => (
              <p key={block.id} className="text-sm">
                <span className="font-medium">{block.name}</span>
                <span className="text-ink/45">
                  {" "}
                  · {block.type} · {block.trials.length} trials · {block.randomization}
                </span>
              </p>
            ))}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
