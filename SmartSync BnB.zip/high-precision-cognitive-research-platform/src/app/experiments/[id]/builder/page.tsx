import { notFound, redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { experiments } from "@/db/schema";
import { Builder } from "@/components/builder";
import { getCurrentResearcher } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function BuilderPage({ params }: { params: Promise<{ id: string }> }) {
  const researcher = await getCurrentResearcher();
  if (!researcher) redirect("/login");
  const { id } = await params;
  const [experiment] = await db
    .select()
    .from(experiments)
    .where(and(eq(experiments.id, id), eq(experiments.researcherId, researcher.id)))
    .limit(1);
  if (!experiment) notFound();
  return <Builder experiment={experiment} />;
}
