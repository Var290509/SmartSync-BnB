import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { experiments, participantSessions, trialResponses } from "@/db/schema";
import { AppShell } from "@/components/app-shell";
import { getCurrentResearcher, toPublicResearcher } from "@/lib/auth";
import { summarizeTrials } from "@/lib/stats";
import { formatMs, formatPct } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function ResultsPage({ params }: { params: Promise<{ id: string }> }) {
  const researcher = await getCurrentResearcher();
  if (!researcher) redirect("/login");
  const { id } = await params;
  const [experiment] = await db
    .select()
    .from(experiments)
    .where(and(eq(experiments.id, id), eq(experiments.researcherId, researcher.id)))
    .limit(1);
  if (!experiment) notFound();

  const sessions = await db
    .select()
    .from(participantSessions)
    .where(eq(participantSessions.experimentId, id))
    .orderBy(desc(participantSessions.startedAt));

  const trials = await db.select().from(trialResponses).where(eq(trialResponses.experimentId, id));
  const summary = summarizeTrials(trials);
  const maxBin = Math.max(1, ...summary.histogram.map((bin) => bin.count));

  return (
    <AppShell researcher={toPublicResearcher(researcher)}>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-teal-2">{experiment.slug} · anonymous export</p>
          <h1 className="mt-2 font-serif text-5xl">Results</h1>
        </div>
        <div className="flex gap-2">
          <Link href={`/experiments/${experiment.id}`} className="rounded-full border border-ink/10 px-4 py-2 text-sm">
            Overview
          </Link>
          <a href={`/api/experiments/${experiment.id}/export`} className="rounded-full bg-ink px-4 py-2 text-sm text-paper">
            Download CSV
          </a>
        </div>
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-4">
        {[
          ["Mean RT", formatMs(summary.meanRt)],
          ["Median RT", formatMs(summary.medianRt)],
          ["Accuracy", formatPct(summary.accuracy)],
          ["Onset |error|", formatMs(summary.meanOnsetError, 2)],
        ].map(([label, value]) => (
          <div key={label} className="rounded-3xl bg-white p-5">
            <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink/40">{label}</p>
            <p className="mt-2 font-serif text-3xl">{value}</p>
          </div>
        ))}
      </div>

      <section className="mt-8 rounded-[28px] bg-white p-6">
        <h2 className="font-serif text-2xl">RT distribution</h2>
        <div className="mt-6 flex h-40 items-end gap-1">
          {summary.histogram.map((bin) => (
            <div key={bin.start} className="flex flex-1 flex-col items-center justify-end">
              <div
                className="w-full rounded-t bg-ink"
                style={{ height: `${(bin.count / maxBin) * 140}px` }}
              />
              <span className="mt-2 font-mono text-[9px] text-ink/40">{Math.round(bin.start)}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-6 rounded-[28px] bg-white p-6">
        <h2 className="font-serif text-2xl">By condition</h2>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink/40">
              <tr>
                <th className="pb-2">Condition</th>
                <th className="pb-2">N</th>
                <th className="pb-2">Mean RT</th>
                <th className="pb-2">Median RT</th>
                <th className="pb-2">Accuracy</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(summary.byCondition).map(([condition, row]) => (
                <tr key={condition} className="border-t border-ink/10">
                  <td className="py-2">{condition}</td>
                  <td>{row.n}</td>
                  <td>{formatMs(row.meanRt)}</td>
                  <td>{formatMs(row.medianRt)}</td>
                  <td>{formatPct(row.accuracy)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="mt-6 rounded-[28px] bg-white p-6">
        <h2 className="font-serif text-2xl">Sessions</h2>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink/40">
              <tr>
                <th className="pb-2">Anonymous ID</th>
                <th className="pb-2">Status</th>
                <th className="pb-2">Timing</th>
                <th className="pb-2">Hz</th>
                <th className="pb-2">Jitter</th>
              </tr>
            </thead>
            <tbody>
              {sessions.map((session) => (
                <tr key={session.id} className="border-t border-ink/10">
                  <td className="py-2 font-mono">{session.anonymousId}</td>
                  <td>{session.status}</td>
                  <td>{session.timingQuality}</td>
                  <td>{session.refreshHz?.toFixed(1) ?? "—"}</td>
                  <td>{session.frameJitterMs?.toFixed(2) ?? "—"}</td>
                </tr>
              ))}
              {sessions.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-6 text-ink/45">
                    No sessions yet. Publish the study and share the recruitment link.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </AppShell>
  );
}
