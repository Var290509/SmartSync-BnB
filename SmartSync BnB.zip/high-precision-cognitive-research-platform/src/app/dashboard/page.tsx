import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { experiments, participantSessions } from "@/db/schema";
import { AppShell } from "@/components/app-shell";
import { getCurrentResearcher, toPublicResearcher } from "@/lib/auth";
import { countTrials } from "@/lib/experiment";
import { relativeTime } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const researcher = await getCurrentResearcher();
  if (!researcher) redirect("/login");

  const rows = await db
    .select()
    .from(experiments)
    .where(eq(experiments.researcherId, researcher.id))
    .orderBy(desc(experiments.updatedAt));

  const sessions = rows.length
    ? await db
        .select()
        .from(participantSessions)
        .where(
          inArray(
            participantSessions.experimentId,
            rows.map((row) => row.id),
          ),
        )
    : [];

  const byExp = new Map<string, { total: number; completed: number }>();
  for (const session of sessions) {
    const current = byExp.get(session.experimentId) ?? { total: 0, completed: 0 };
    current.total += 1;
    if (session.status === "completed") current.completed += 1;
    byExp.set(session.experimentId, current);
  }

  const openCount = rows.filter((row) => row.status === "published").length;
  const sessionCount = [...byExp.values()].reduce((sum, value) => sum + value.total, 0);

  return (
    <AppShell researcher={toPublicResearcher(researcher)}>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-teal-2">Lab bench</p>
          <h1 className="mt-2 font-serif text-5xl">Protocols</h1>
        </div>
        <Link href="/experiments/new" className="rounded-full bg-ink px-5 py-2.5 text-sm text-paper">
          New experiment
        </Link>
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-3">
        {[
          ["Active studies", String(openCount)],
          ["Protocols", String(rows.length)],
          ["Sessions collected", String(sessionCount)],
        ].map(([label, value]) => (
          <div key={label} className="rounded-3xl bg-white p-5 shadow-[0_12px_40px_rgba(40,30,10,0.06)]">
            <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink/40">{label}</p>
            <p className="mt-2 font-serif text-4xl">{value}</p>
          </div>
        ))}
      </div>

      <div className="mt-10 space-y-3">
        {rows.length === 0 && (
          <div className="rounded-[28px] bg-white p-10 text-ink/60">
            No protocols yet. Start from a Stroop, flanker, or blank canvas.
          </div>
        )}
        {rows.map((experiment) => {
          const stats = byExp.get(experiment.id) ?? { total: 0, completed: 0 };
          return (
            <article
              key={experiment.id}
              className="grid gap-4 rounded-[28px] bg-white p-6 shadow-[0_12px_40px_rgba(40,30,10,0.05)] md:grid-cols-[1fr_auto]"
            >
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-teal-2">{experiment.slug}</p>
                  <span className="rounded-full bg-ink/5 px-2 py-0.5 text-[11px] uppercase tracking-wide">
                    {experiment.status}
                  </span>
                </div>
                <h2 className="mt-2 font-serif text-3xl">{experiment.title}</h2>
                <p className="mt-1 text-sm text-ink/55">{experiment.description || "No synopsis yet."}</p>
                <p className="mt-3 font-mono text-[11px] text-ink/40">
                  {countTrials(experiment.definition)} trials · {stats.completed}/{stats.total} complete sessions ·
                  updated {relativeTime(experiment.updatedAt)}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 md:flex-col md:items-end">
                <Link href={`/experiments/${experiment.id}`} className="rounded-full bg-ink px-4 py-2 text-sm text-paper">
                  Open
                </Link>
                <Link href={`/experiments/${experiment.id}/builder`} className="rounded-full border border-ink/10 px-4 py-2 text-sm">
                  Builder
                </Link>
                <Link href={`/experiments/${experiment.id}/results`} className="rounded-full border border-ink/10 px-4 py-2 text-sm">
                  Results
                </Link>
              </div>
            </article>
          );
        })}
      </div>
    </AppShell>
  );
}
