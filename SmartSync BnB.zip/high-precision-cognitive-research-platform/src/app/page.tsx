import Image from "next/image";
import Link from "next/link";
import { count } from "drizzle-orm";
import { db } from "@/db";
import { experiments, participantSessions, trialResponses } from "@/db/schema";
import { getCurrentResearcher, toPublicResearcher } from "@/lib/auth";
import { Footer, MarketingNav } from "@/components/nav";
import { TimingDemo } from "@/components/timing-demo";
import { ensureDemoSeed } from "@/lib/seed";
import { TEMPLATE_LIST } from "@/lib/templates";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await ensureDemoSeed();
  const researcher = await getCurrentResearcher();
  let sessionCount = 0;
  let trialCount = 0;
  let studyCount = 0;
  try {
    const [sessions] = await db.select({ value: count() }).from(participantSessions);
    const [trials] = await db.select({ value: count() }).from(trialResponses);
    const [studies] = await db.select({ value: count() }).from(experiments);
    sessionCount = Number(sessions.value);
    trialCount = Number(trials.value);
    studyCount = Number(studies.value);
  } catch {
    sessionCount = 0;
  }

  return (
    <div className="grain min-h-screen bg-ink text-paper">
      <div className="grid-bg absolute inset-x-0 top-0 h-[720px] opacity-60" />
      <MarketingNav researcher={researcher ? toPublicResearcher(researcher) : null} />

      <main className="relative">
        <section className="mx-auto grid w-full max-w-6xl gap-12 px-6 pb-20 pt-8 lg:grid-cols-[1.1fr_0.9fr] lg:items-end">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.28em] text-teal">Cognitive science · SaaS</p>
            <h1 className="mt-5 font-serif text-[clamp(3rem,8vw,6.4rem)] leading-[0.92] tracking-tight">
              Lab timing.
              <span className="block text-gold">Browser reach.</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-mist">
              Aperture lets researchers design millisecond-sensitive behavioural experiments visually, deploy them to
              anyone with a browser, and collect anonymous trial data that meets IRB and GDPR expectations.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/register" className="rounded-full bg-teal px-6 py-3 text-sm font-medium text-ink">
                Start a study
              </Link>
              <Link href="/studies" className="rounded-full border border-[var(--color-line)] px-6 py-3 text-sm text-paper">
                Take a live experiment
              </Link>
            </div>
            <dl className="mt-12 grid max-w-lg grid-cols-3 gap-4 font-mono text-xs uppercase tracking-[0.16em] text-mist">
              <div>
                <dt>Sessions</dt>
                <dd className="mt-1 font-serif text-3xl normal-case tracking-tight text-paper">{sessionCount}</dd>
              </div>
              <div>
                <dt>Trials</dt>
                <dd className="mt-1 font-serif text-3xl normal-case tracking-tight text-paper">{trialCount}</dd>
              </div>
              <div>
                <dt>Protocols</dt>
                <dd className="mt-1 font-serif text-3xl normal-case tracking-tight text-paper">{studyCount}</dd>
              </div>
            </dl>
          </div>
          <div className="relative">
            <Image
              src="/images/hero-lab.webp"
              alt="Dark laboratory monitor showing a timed cognitive trial"
              width={1200}
              height={800}
              className="h-[420px] w-full rounded-[32px] object-cover"
              priority
            />
            <p className="mt-3 font-mono text-[11px] uppercase tracking-[0.2em] text-mist">
              Stimulus onset locked to vsync · RT via performance.now()
            </p>
          </div>
        </section>

        <section className="mx-auto w-full max-w-6xl px-6 py-8">
          <div className="grid gap-4 md:grid-cols-3">
            {[
              {
                kicker: "01",
                title: "High-precision timing",
                body: "Presentation is scheduled against the animation frame, with onset error, refresh estimate, and jitter stored on every session.",
              },
              {
                kicker: "02",
                title: "Visual protocol builder",
                body: "Compose blocks, randomise trials, map keys, and branch by accuracy — without writing a line of experiment code.",
              },
              {
                kicker: "03",
                title: "Anonymous by design",
                body: "Participants receive a one-time code. No names, emails, or IP addresses. Consent, withdraw, and CSV export are first-class.",
              },
            ].map((item) => (
              <article key={item.kicker} className="rounded-[24px] border border-[var(--color-line)] bg-ink-2 p-6">
                <p className="font-mono text-xs text-gold">{item.kicker}</p>
                <h2 className="mt-3 font-serif text-2xl">{item.title}</h2>
                <p className="mt-3 text-sm leading-relaxed text-mist">{item.body}</p>
              </article>
            ))}
          </div>
        </section>

        <section id="engine" className="mx-auto grid w-full max-w-6xl gap-10 px-6 py-20 lg:grid-cols-2 lg:items-center">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.22em] text-teal">Timing engine</p>
            <h2 className="mt-3 font-serif text-4xl leading-tight md:text-5xl">
              Milliseconds, treated as a first-class measurement.
            </h2>
            <p className="mt-5 text-mist leading-relaxed">
              Web experiments fail when they pretend the browser is a tachistoscope. Aperture does not. We calibrate
              display refresh, present stimuli on the next vertical sync, and record both scheduled and actual onset so
              researchers can filter noisy sessions instead of trusting a black box.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-paper/90">
              <li>— <span className="font-mono text-teal">requestAnimationFrame</span> presentation lock</li>
              <li>— Frame-interval jitter and estimated Hz stored per session</li>
              <li>— Anticipation, timeout, and onset-error flags on every trial</li>
              <li>— Quality grades: excellent / good / fair / poor</li>
            </ul>
          </div>
          <TimingDemo />
        </section>

        <section id="builder" className="px-6 py-12">
          <div className="mx-auto grid w-full max-w-6xl overflow-hidden rounded-[36px] bg-[#14110c] md:grid-cols-2">
            <div className="p-8 md:p-12">
              <p className="font-mono text-xs uppercase tracking-[0.22em] text-gold">Visual builder</p>
              <h2 className="mt-3 font-serif text-4xl text-paper">Design the trial the way you talk about it.</h2>
              <p className="mt-4 text-mist leading-relaxed">
                Blocks, practice vs experimental, shuffle, ISI, SOA jitter, key maps, and condition labels — edited as
                cards, saved as a versioned JSON protocol, executed by the same engine that runs published studies.
              </p>
              <Link href="/register" className="mt-8 inline-flex rounded-full bg-paper px-5 py-2.5 text-sm text-ink">
                Open the builder
              </Link>
            </div>
            <Image
              src="/images/builder-ui.webp"
              alt="Researcher desk with a visual experiment builder on a laptop"
              width={1200}
              height={800}
              className="h-full min-h-[280px] w-full object-cover"
            />
          </div>
        </section>

        <section className="mx-auto w-full max-w-6xl px-6 py-16">
          <div className="flex items-end justify-between gap-4">
            <div>
              <p className="font-mono text-xs uppercase tracking-[0.22em] text-teal">Protocol library</p>
              <h2 className="mt-3 font-serif text-4xl">Start from a canonical task.</h2>
            </div>
            <Link href="/register" className="hidden text-sm text-mist hover:text-paper md:block">
              Use a template →
            </Link>
          </div>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {TEMPLATE_LIST.filter((item) => item.key !== "custom").map((item) => (
              <article key={item.key} className="rounded-[24px] border border-[var(--color-line)] p-5">
                <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-gold">{item.family}</p>
                <h3 className="mt-2 font-serif text-2xl">{item.name}</h3>
                <p className="mt-2 text-sm text-mist">{item.blurb}</p>
                <p className="mt-4 font-mono text-[11px] text-teal">
                  ~{item.minutes} min · {item.measures.join(" · ")}
                </p>
              </article>
            ))}
          </div>
        </section>

        <section className="mx-auto grid w-full max-w-6xl gap-8 px-6 py-10 lg:grid-cols-2">
          <Image
            src="/images/privacy-vault.webp"
            alt="Archival boxes and anonymous participant codes"
            width={1200}
            height={800}
            className="h-[360px] w-full rounded-[28px] object-cover"
          />
          <div className="flex flex-col justify-center">
            <p className="font-mono text-xs uppercase tracking-[0.22em] text-gold">Ethics</p>
            <h2 className="mt-3 font-serif text-4xl">Anonymous identifiers, not people-as-rows.</h2>
            <p className="mt-4 leading-relaxed text-mist">
              Every session is stored as a participant code such as P-8F3A2C. Consent is captured before the first
              stimulus. Escape withdraws the session. Researchers export tidy CSVs; they never receive a name they did
              not collect.
            </p>
            <div className="mt-6 flex gap-4 text-sm">
              <Link href="/ethics" className="text-teal">
                IRB checklist
              </Link>
              <Link href="/privacy" className="text-mist">
                Privacy notice
              </Link>
            </div>
          </div>
        </section>

        <section className="mx-auto w-full max-w-6xl px-6 py-16">
          <div className="overflow-hidden rounded-[32px] border border-[var(--color-line)]">
            <Image
              src="/images/pexels-photo-17483867.webp"
              alt="Abstract neural network visualisation"
              width={1600}
              height={720}
              className="h-[280px] w-full object-cover"
            />
            <div className="grid gap-6 p-8 md:grid-cols-3">
              {[
                ["Calibrate", "Estimate refresh and jitter before trial one."],
                ["Present", "Lock stimulus onset to the next display frame."],
                ["Archive", "Keep anonymous RTs, accuracy, and timing metadata."],
              ].map(([title, body]) => (
                <div key={title}>
                  <h3 className="font-serif text-2xl">{title}</h3>
                  <p className="mt-2 text-sm text-mist">{body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto w-full max-w-6xl px-6 pb-20">
          <div className="rounded-[32px] bg-paper px-8 py-12 text-ink md:px-14">
            <p className="font-mono text-xs uppercase tracking-[0.22em] text-teal-2">Now recruiting labs</p>
            <h2 className="mt-3 max-w-3xl font-serif text-4xl leading-tight md:text-5xl">
              Move a desktop protocol onto the web without giving up the millisecond.
            </h2>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/register" className="rounded-full bg-ink px-6 py-3 text-sm text-paper">
                Create a researcher account
              </Link>
              <Link href="/login" className="rounded-full border border-ink/15 px-6 py-3 text-sm">
                Sign in to the bench
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
