import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { experiments } from "@/db/schema";
import { getCurrentResearcher } from "@/lib/auth";
import { apiError } from "@/lib/api-error";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const researcher = await getCurrentResearcher();
    if (!researcher) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const { id } = await params;
    const body = (await request.json().catch(() => null)) as { status?: string } | null;
    const status = body?.status === "paused" ? "paused" : body?.status === "draft" ? "draft" : "published";

    const [existing] = await db
      .select()
      .from(experiments)
      .where(and(eq(experiments.id, id), eq(experiments.researcherId, researcher.id)))
      .limit(1);
    if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const [updated] = await db
      .update(experiments)
      .set({
        status,
        publishedAt: status === "published" ? existing.publishedAt ?? new Date() : existing.publishedAt,
        updatedAt: new Date(),
      })
      .where(eq(experiments.id, id))
      .returning();

    return NextResponse.json({ experiment: updated });
  } catch (err) {
    return apiError(err, "Could not update the experiment status.");
  }
}
