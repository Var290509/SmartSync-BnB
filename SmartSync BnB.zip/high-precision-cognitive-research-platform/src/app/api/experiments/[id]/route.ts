import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { experiments } from "@/db/schema";
import { getCurrentResearcher } from "@/lib/auth";
import { estimatedMinutes } from "@/lib/experiment";
import type { ExperimentDefinition } from "@/lib/types";
import { apiError } from "@/lib/api-error";

async function loadOwned(id: string, researcherId: string) {
  const [row] = await db
    .select()
    .from(experiments)
    .where(and(eq(experiments.id, id), eq(experiments.researcherId, researcherId)))
    .limit(1);
  return row ?? null;
}

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const researcher = await getCurrentResearcher();
    if (!researcher) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const { id } = await params;
    const row = await loadOwned(id, researcher.id);
    if (!row) return NextResponse.json({ error: "Not found" }, { status: 404 });
    return NextResponse.json({ experiment: row });
  } catch (err) {
    return apiError(err, "Could not load the experiment.");
  }
}

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const researcher = await getCurrentResearcher();
    if (!researcher) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const { id } = await params;
    const existing = await loadOwned(id, researcher.id);
    if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const body = (await request.json().catch(() => null)) as {
      title?: string;
      description?: string;
      irbNote?: string | null;
      definition?: ExperimentDefinition;
      status?: string;
    } | null;

    const definition = body?.definition ?? existing.definition;
    const [updated] = await db
      .update(experiments)
      .set({
        title: body?.title?.trim() || existing.title,
        description: body?.description ?? existing.description,
        irbNote: body?.irbNote === undefined ? existing.irbNote : body.irbNote,
        definition,
        estimatedMinutes: estimatedMinutes(definition),
        status: body?.status ?? existing.status,
        updatedAt: new Date(),
      })
      .where(eq(experiments.id, id))
      .returning();

    return NextResponse.json({ experiment: updated });
  } catch (err) {
    return apiError(err, "Could not save the experiment.");
  }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const researcher = await getCurrentResearcher();
    if (!researcher) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const { id } = await params;
    const existing = await loadOwned(id, researcher.id);
    if (!existing) return NextResponse.json({ error: "Not found" }, { status: 404 });
    await db.delete(experiments).where(eq(experiments.id, id));
    return NextResponse.json({ ok: true });
  } catch (err) {
    return apiError(err, "Could not delete the experiment.");
  }
}
