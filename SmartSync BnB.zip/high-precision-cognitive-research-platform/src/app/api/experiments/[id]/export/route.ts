import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { experiments, participantSessions, trialResponses } from "@/db/schema";
import { getCurrentResearcher } from "@/lib/auth";
import { apiError } from "@/lib/api-error";

function csvEscape(value: unknown) {
  const text = value == null ? "" : String(value);
  if (/[",\n]/.test(text)) return `"${text.replaceAll('"', '""')}"`;
  return text;
}

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const researcher = await getCurrentResearcher();
    if (!researcher) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    const { id } = await params;

    const [experiment] = await db
      .select()
      .from(experiments)
      .where(and(eq(experiments.id, id), eq(experiments.researcherId, researcher.id)))
      .limit(1);
    if (!experiment) return NextResponse.json({ error: "Not found" }, { status: 404 });

    const rows = await db
      .select({
        anonymousId: participantSessions.anonymousId,
        sessionStatus: participantSessions.status,
        timingQuality: participantSessions.timingQuality,
        refreshHz: participantSessions.refreshHz,
        frameJitterMs: participantSessions.frameJitterMs,
        startedAt: participantSessions.startedAt,
        completedAt: participantSessions.completedAt,
        trialIndex: trialResponses.trialIndex,
        blockId: trialResponses.blockId,
        trialId: trialResponses.trialId,
        stimulusLabel: trialResponses.stimulusLabel,
        condition: trialResponses.condition,
        correctKey: trialResponses.correctKey,
        responseKey: trialResponses.responseKey,
        isCorrect: trialResponses.isCorrect,
        isTimeout: trialResponses.isTimeout,
        rtMs: trialResponses.rtMs,
        onsetErrorMs: trialResponses.onsetErrorMs,
      })
      .from(trialResponses)
      .innerJoin(participantSessions, eq(participantSessions.id, trialResponses.sessionId))
      .where(eq(trialResponses.experimentId, id));

    const headers = [
      "anonymous_id",
      "session_status",
      "timing_quality",
      "refresh_hz",
      "frame_jitter_ms",
      "started_at",
      "completed_at",
      "trial_index",
      "block_id",
      "trial_id",
      "stimulus",
      "condition",
      "correct_key",
      "response_key",
      "is_correct",
      "is_timeout",
      "rt_ms",
      "onset_error_ms",
    ];

    const lines = [headers.join(",")];
    for (const row of rows) {
      lines.push(
        [
          row.anonymousId,
          row.sessionStatus,
          row.timingQuality,
          row.refreshHz,
          row.frameJitterMs,
          row.startedAt?.toISOString(),
          row.completedAt?.toISOString(),
          row.trialIndex,
          row.blockId,
          row.trialId,
          row.stimulusLabel,
          row.condition,
          row.correctKey,
          row.responseKey,
          row.isCorrect,
          row.isTimeout,
          row.rtMs,
          row.onsetErrorMs,
        ]
          .map(csvEscape)
          .join(","),
      );
    }

    return new NextResponse(lines.join("\n"), {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="${experiment.slug}-anonymous-data.csv"`,
      },
    });
  } catch (err) {
    return apiError(err, "Could not export results.");
  }
}
