import { desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { experiments } from "@/db/schema";
import { getCurrentResearcher } from "@/lib/auth";
import { estimatedMinutes } from "@/lib/experiment";
import { buildTemplate } from "@/lib/templates";
import { publicCode } from "@/lib/utils";
import { apiError } from "@/lib/api-error";

export async function GET() {
  try {
    const researcher = await getCurrentResearcher();
    if (!researcher) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const rows = await db
      .select()
      .from(experiments)
      .where(eq(experiments.researcherId, researcher.id))
      .orderBy(desc(experiments.updatedAt));

    return NextResponse.json({ experiments: rows });
  } catch (err) {
    return apiError(err, "Could not load experiments.");
  }
}

export async function POST(request: Request) {
  try {
    const researcher = await getCurrentResearcher();
    if (!researcher) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = (await request.json().catch(() => null)) as {
      title?: string;
      description?: string;
      templateKey?: string;
      irbNote?: string;
    } | null;

    const title = body?.title?.trim() || "Untitled experiment";
    const templateKey = body?.templateKey || "custom";
    const definition = buildTemplate(templateKey);

    const [created] = await db
      .insert(experiments)
      .values({
        researcherId: researcher.id,
        title,
        description: body?.description?.trim() || "",
        slug: publicCode(6),
        status: "draft",
        templateKey,
        definition,
        irbNote: body?.irbNote?.trim() || null,
        estimatedMinutes: estimatedMinutes(definition),
      })
      .returning();

    return NextResponse.json({ experiment: created });
  } catch (err) {
    return apiError(err, "Could not create the experiment.");
  }
}
