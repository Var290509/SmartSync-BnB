import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { experiments, participantSessions, trialResponses } from "@/db/schema";
import { apiError } from "@/lib/api-error";

export async function POST(request: Request, { params }: { params: Promise<{ code: string }> }) {
  try {
    const { code } = await params;
    const body = (await request.json().catch(() => null)) as {
      sessionId?: string;
      preview?: boolean;
      blockId?: string;
      trialId?: string;
      trialIndex?: number;
      stimulusLabel?: string;
      condition?: string;
      correctKey?: string | null;
      responseKey?: string | null;
      isCorrect?: boolean | null;
      isTimeout?: boolean;
      rtMs?: number | null;
      scheduledOnsetMs?: number | null;
      actualOnsetMs?: number | null;
      onsetErrorMs?: number | null;
    } | null;

    if (body?.preview || body?.sessionId === "preview") {
      return NextResponse.json({ ok: true, preview: true });
    }

    const [experiment] = await db.select().from(experiments).where(eq(experiments.slug, code.toUpperCase())).limit(1);
    if (!experiment || !body?.sessionId) {
      return NextResponse.json({ error: "Invalid session" }, { status: 400 });
    }

    const [session] = await db
      .select()
      .from(participantSessions)
      .where(eq(participantSessions.id, body.sessionId))
      .limit(1);
    if (!session || session.experimentId !== experiment.id) {
      return NextResponse.json({ error: "Invalid session" }, { status: 400 });
    }

    await db.insert(trialResponses).values({
      sessionId: session.id,
      experimentId: experiment.id,
      blockId: body.blockId ?? "unknown",
      trialId: body.trialId ?? "unknown",
      trialIndex: body.trialIndex ?? 0,
      stimulusLabel: body.stimulusLabel ?? null,
      condition: body.condition ?? null,
      correctKey: body.correctKey ?? null,
      responseKey: body.responseKey ?? null,
      isCorrect: body.isCorrect ?? null,
      isTimeout: Boolean(body.isTimeout),
      rtMs: body.rtMs ?? null,
      scheduledOnsetMs: body.scheduledOnsetMs ?? null,
      actualOnsetMs: body.actualOnsetMs ?? null,
      onsetErrorMs: body.onsetErrorMs ?? null,
    });

    return NextResponse.json({ ok: true });
  } catch (err) {
    return apiError(err, "Could not record the response.");
  }
}
