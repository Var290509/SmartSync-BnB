import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { experiments, participantSessions } from "@/db/schema";
import { getCurrentResearcher } from "@/lib/auth";
import type { CalibrationResult, Demographics } from "@/lib/types";
import { anonymousId } from "@/lib/utils";
import { apiError } from "@/lib/api-error";

export async function POST(request: Request, { params }: { params: Promise<{ code: string }> }) {
  try {
    const { code } = await params;
    const body = (await request.json().catch(() => null)) as {
      preview?: boolean;
      consent?: boolean;
      calibration?: CalibrationResult;
      demographics?: Demographics;
      screen?: { width: number; height: number };
      locale?: string;
      timezone?: string;
    } | null;

    const [experiment] = await db.select().from(experiments).where(eq(experiments.slug, code.toUpperCase())).limit(1);
    if (!experiment) return NextResponse.json({ error: "Experiment not found" }, { status: 404 });

    if (body?.preview) {
      const researcher = await getCurrentResearcher();
      if (!researcher || researcher.id !== experiment.researcherId) {
        return NextResponse.json({ error: "Preview requires the owning researcher" }, { status: 401 });
      }
      return NextResponse.json({
        preview: true,
        sessionId: "preview",
        anonymousId: "P-PREVIEW",
        experiment,
      });
    }

    if (experiment.status !== "published") {
      return NextResponse.json({ error: "This study is not currently open." }, { status: 403 });
    }
    if (!body?.consent) {
      return NextResponse.json({ error: "Consent is required." }, { status: 400 });
    }

    const id = anonymousId();
    const [session] = await db
      .insert(participantSessions)
      .values({
        experimentId: experiment.id,
        anonymousId: id,
        status: "in_progress",
        consentAt: new Date(),
        userAgent: request.headers.get("user-agent"),
        locale: body.locale ?? null,
        timezone: body.timezone ?? null,
        screenWidth: body.screen?.width ?? null,
        screenHeight: body.screen?.height ?? null,
        refreshHz: body.calibration?.refreshHz ?? null,
        timingQuality: body.calibration?.quality ?? null,
        frameJitterMs: body.calibration?.frameJitterMs ?? null,
        demographics: body.demographics ?? null,
      })
      .returning();

    return NextResponse.json({
      preview: false,
      sessionId: session.id,
      anonymousId: session.anonymousId,
      experiment,
    });
  } catch (err) {
    return apiError(err, "Could not start the session.");
  }
}
