import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { experiments, participantSessions } from "@/db/schema";
import { apiError } from "@/lib/api-error";

export async function POST(request: Request, { params }: { params: Promise<{ code: string }> }) {
  try {
    const { code } = await params;
    const body = (await request.json().catch(() => null)) as {
      sessionId?: string;
      preview?: boolean;
      withdrawn?: boolean;
    } | null;

    if (body?.preview || body?.sessionId === "preview") {
      return NextResponse.json({ ok: true, preview: true });
    }

    const [experiment] = await db.select().from(experiments).where(eq(experiments.slug, code.toUpperCase())).limit(1);
    if (!experiment || !body?.sessionId) {
      return NextResponse.json({ error: "Invalid session" }, { status: 400 });
    }

    await db
      .update(participantSessions)
      .set({
        status: body.withdrawn ? "withdrawn" : "completed",
        completedAt: new Date(),
      })
      .where(eq(participantSessions.id, body.sessionId));

    return NextResponse.json({ ok: true });
  } catch (err) {
    return apiError(err, "Could not complete the session.");
  }
}
