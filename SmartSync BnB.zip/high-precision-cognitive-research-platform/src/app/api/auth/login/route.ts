import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { researchers } from "@/db/schema";
import { createSession, SESSION_COOKIE, sessionCookieOptions, toPublicResearcher, verifyPassword } from "@/lib/auth";
import { apiError } from "@/lib/api-error";

export async function POST(request: Request) {
  try {
    const body = (await request.json().catch(() => null)) as { email?: string; password?: string } | null;
    const email = body?.email?.trim().toLowerCase() ?? "";
    const password = body?.password ?? "";

    const [researcher] = await db.select().from(researchers).where(eq(researchers.email, email)).limit(1);
    if (!researcher || !verifyPassword(password, researcher.passwordHash)) {
      return NextResponse.json({ error: "Email or password is incorrect." }, { status: 401 });
    }

    const session = await createSession(researcher.id);
    const response = NextResponse.json({ researcher: toPublicResearcher(researcher) });
    response.cookies.set(SESSION_COOKIE, session.token, sessionCookieOptions(session.expiresAt));
    return response;
  } catch (err) {
    return apiError(err, "Could not sign in.");
  }
}
