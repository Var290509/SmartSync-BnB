import { NextResponse } from "next/server";
import { destroySession, SESSION_COOKIE } from "@/lib/auth";
import { apiError } from "@/lib/api-error";

export async function POST() {
  try {
    await destroySession();
    const response = NextResponse.json({ ok: true });
    response.cookies.set(SESSION_COOKIE, "", { path: "/", maxAge: 0 });
    return response;
  } catch (err) {
    return apiError(err, "Could not sign out.");
  }
}
