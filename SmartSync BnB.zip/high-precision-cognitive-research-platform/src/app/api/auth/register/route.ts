import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { researchers } from "@/db/schema";
import { createSession, hashPassword, SESSION_COOKIE, sessionCookieOptions, toPublicResearcher } from "@/lib/auth";
import { apiError } from "@/lib/api-error";

export async function POST(request: Request) {
  try {
    const body = (await request.json().catch(() => null)) as {
      name?: string;
      email?: string;
      password?: string;
      institution?: string;
    } | null;

    const name = body?.name?.trim() ?? "";
    const email = body?.email?.trim().toLowerCase() ?? "";
    const password = body?.password ?? "";
    const institution = body?.institution?.trim() || null;

    if (name.length < 2 || !email.includes("@") || password.length < 8) {
      return NextResponse.json(
        { error: "Provide a name, valid email, and a password of at least 8 characters." },
        { status: 400 },
      );
    }

    const existing = await db.select({ id: researchers.id }).from(researchers).where(eq(researchers.email, email)).limit(1);
    if (existing[0]) {
      return NextResponse.json({ error: "An account with that email already exists." }, { status: 409 });
    }

    const [researcher] = await db
      .insert(researchers)
      .values({
        name,
        email,
        institution,
        passwordHash: hashPassword(password),
      })
      .returning();

    const session = await createSession(researcher.id);
    const response = NextResponse.json({ researcher: toPublicResearcher(researcher) });
    response.cookies.set(SESSION_COOKIE, session.token, sessionCookieOptions(session.expiresAt));
    return response;
  } catch (err) {
    return apiError(err, "Could not create the account.");
  }
}
