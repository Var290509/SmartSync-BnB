import { getCurrentResearcher, toPublicResearcher } from "@/lib/auth";
import { Footer, MarketingNav } from "@/components/nav";

export const dynamic = "force-dynamic";

export default async function PrivacyPage() {
  const researcher = await getCurrentResearcher();
  return (
    <div className="min-h-screen bg-ink text-paper">
      <MarketingNav researcher={researcher ? toPublicResearcher(researcher) : null} />
      <article className="mx-auto max-w-3xl px-6 py-16">
        <p className="font-mono text-xs uppercase tracking-[0.22em] text-teal">Privacy</p>
        <h1 className="mt-3 font-serif text-5xl">What Aperture stores — and what it refuses to store.</h1>
        <div className="mt-8 space-y-5 text-mist leading-relaxed">
          <p>
            Participant sessions are keyed by a random anonymous code. We do not ask for names, emails, or dates of
            birth. Optional demographics are coarse (age range, handedness) and never required.
          </p>
          <p>
            We do not persist IP addresses. User-agent, locale, timezone, and screen size are kept only as technical
            metadata for timing quality and device class.
          </p>
          <p>
            Researcher accounts store name, email, institution, and a salted password hash. Session cookies are HTTP-only.
          </p>
          <p>
            Trial data belong to the hosting researcher. Exports are CSV files of anonymous rows. Participants may
            withdraw mid-study; withdrawn sessions are flagged and can be excluded from analysis.
          </p>
          <p>Questions about a specific dataset should go to the researcher named on the consent screen, not to Aperture staff.</p>
        </div>
      </article>
      <Footer />
    </div>
  );
}
