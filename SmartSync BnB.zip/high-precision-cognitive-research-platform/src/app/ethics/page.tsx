import { getCurrentResearcher, toPublicResearcher } from "@/lib/auth";
import { Footer, MarketingNav } from "@/components/nav";

export const dynamic = "force-dynamic";

export default async function EthicsPage() {
  const researcher = await getCurrentResearcher();
  return (
    <div className="min-h-screen bg-ink text-paper">
      <MarketingNav researcher={researcher ? toPublicResearcher(researcher) : null} />
      <article className="mx-auto max-w-3xl px-6 py-16">
        <p className="font-mono text-xs uppercase tracking-[0.22em] text-gold">Ethics & IRB</p>
        <h1 className="mt-3 font-serif text-5xl">Built to sit inside a protocol, not around it.</h1>
        <ol className="mt-10 space-y-6 text-mist">
          {[
            ["Informed consent", "No trial is recorded until the participant explicitly consents. The consent copy is part of the protocol JSON."],
            ["Right to withdraw", "Escape ends the session immediately and marks it withdrawn."],
            ["Anonymity", "Identifiers are random codes. There is no account for participants."],
            ["Timing transparency", "Each session stores refresh estimate, frame jitter, and onset error so reviewers can judge data quality."],
            ["Data minimisation", "Optional demographics are categorical. Researchers are discouraged from collecting direct identifiers."],
            ["Export & retention", "Researchers can download anonymous CSVs and delete a protocol, cascading session rows."],
          ].map(([title, body], index) => (
            <li key={title} className="grid gap-2 md:grid-cols-[80px_1fr]">
              <span className="font-mono text-gold">0{index + 1}</span>
              <div>
                <h2 className="font-serif text-2xl text-paper">{title}</h2>
                <p className="mt-1 leading-relaxed">{body}</p>
              </div>
            </li>
          ))}
        </ol>
      </article>
      <Footer />
    </div>
  );
}
