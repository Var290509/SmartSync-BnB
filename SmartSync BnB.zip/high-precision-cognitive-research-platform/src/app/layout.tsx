import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Fraunces, IBM_Plex_Mono, Outfit } from "next/font/google";
import "./globals.css";

const outfit = Outfit({
  subsets: ["latin"],
  variable: "--font-outfit",
});

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
});

const ibm = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-ibm",
});

export const metadata: Metadata = {
  title: {
    default: "Aperture — millisecond-accurate web experiments",
    template: "%s · Aperture",
  },
  description:
    "Aperture is a research platform for building, deploying, and analysing high-precision behavioural experiments in the browser — with anonymous data handling built for IRB and GDPR workflows.",
  openGraph: {
    title: "Aperture — millisecond-accurate web experiments",
    description: "No-code experiment builder with a high-precision timing engine for cognitive science.",
    images: ["/images/hero-lab.webp"],
  },
  icons: {
    icon: "/brand/mark.png",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className={`${outfit.variable} ${fraunces.variable} ${ibm.variable} antialiased`}>
        {children}
      </body>
    </html>
  );
}
