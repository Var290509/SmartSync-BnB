import Link from "next/link";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { experiments } from "@/db/schema";
import { Runner } from "@/components/runner";
import { getCurrentResearcher } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function RunPage({
  params,
  searchParams,
}: {
  params: Promise<{ code: string }>;
  searchParams: Promise<{ preview?: string }>;
}) {
  const { code } = await params;
  const query = await searchParams;
  const preview = query.preview === "1";
  const [experiment] = await db
    .select()
    .from(experiments)
    .where(eq(experiments.slug, code.toUpperCase()))
    .limit(1);

  if (!experiment) {
    return (
      <div className="grid min-h-screen place-items-center bg-ink text-paper">
        <div className="text-center">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-gold">Not found</p>
          <h1 className="mt-3 font-serif text-4xl">No experiment with that code.</h1>
          <Link href="/studies" className="mt-6 inline-block text-teal">
            Browse open studies
          </Link>
        </div>
      </div>
    );
  }

  if (experiment.status !== "published" && !preview) {
    return (
      <div className="grid min-h-screen place-items-center bg-ink text-paper">
        <div className="text-center">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-gold">{experiment.slug}</p>
          <h1 className="mt-3 font-serif text-4xl">This study is not recruiting.</h1>
          <Link href="/studies" className="mt-6 inline-block text-teal">
            Browse open studies
          </Link>
        </div>
      </div>
    );
  }

  if (preview) {
    const researcher = await getCurrentResearcher();
    if (!researcher || researcher.id !== experiment.researcherId) {
      return (
        <div className="grid min-h-screen place-items-center bg-ink text-paper">
          <p>Preview is limited to the owning researcher.</p>
        </div>
      );
    }
  }

  return (
    <Runner
      code={experiment.slug}
      definition={experiment.definition}
      title={experiment.title}
      preview={preview}
      estimatedMinutes={experiment.estimatedMinutes}
    />
  );
}
