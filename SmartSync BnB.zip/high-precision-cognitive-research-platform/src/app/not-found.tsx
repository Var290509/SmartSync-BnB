import Link from "next/link";

export default function NotFound() {
  return (
    <div className="grid min-h-screen place-items-center bg-ink px-6 text-paper">
      <div className="text-center">
        <p className="font-mono text-xs uppercase tracking-[0.22em] text-gold">404</p>
        <h1 className="mt-3 font-serif text-5xl">This trial was never scheduled.</h1>
        <Link href="/" className="mt-6 inline-block text-teal">
          Return to Aperture
        </Link>
      </div>
    </div>
  );
}
