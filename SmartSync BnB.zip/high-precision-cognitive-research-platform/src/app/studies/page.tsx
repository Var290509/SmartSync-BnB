import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { experiments } from "@/db/schema";
import { getCurrentResearcher, toPublicResearcher } from "@/lib/auth";
import { Footer, MarketingNav } from "@/components/nav";
import { countTrials } from "@/lib/experiment";
import { ensureDemoSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function StudiesPage() {
  await ensureDemoSeed();
  const researcher = await getCurrentResearcher();
  const published = await db
    .select()
    .from(experiments)
    .where(eq(experiments.status, "published"))
    .orderBy(desc(experiments.publishedAt));

  return (
    <div className="min-h-screen bg-ink text-paper">
      <MarketingNav researcher={researcher ? toPublicResearcher(researcher) : null} />
      <main className="mx-auto w-full max-w-6xl px-6 py-16">
        <p className="font-mono text-xs uppercase tracking-[0.22em] text-teal">Open studies</p>
        <h1 className="mt-3 font-serif text-5xl">Take a live experiment.</h1>
        <p className="mt-4 max-w-2xl text-mist">
          These protocols are currently recruiting. You will see a consent screen first. Nothing identifying is stored.
        </p>
        <div className="mt-10 grid gap-4 md:grid-cols-2">
          {published.length === 0 && (
            <p className="rounded-3xl border border-[var(--color-line)] p-8 text-mist">
              No studies are open yet. Researchers can publish from the lab bench.
            </p>
          )}
          {published.map((study) => (
            <article key={study.id} className="rounded-[28px] border border-[var(--color-line)] p-6">
              <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-gold">{study.slug}</p>
              <h2 className="mt-2 font-serif text-3xl">{study.title}</h2>
              <p className="mt-2 text-sm text-mist">{study.description}</p>
              <p className="mt-4 font-mono text-xs text-teal">
                ~{study.estimatedMinutes} min · {countTrials(study.definition)} trials
              </p>
              <Link
                href={`/run/${study.slug}`}
                className="mt-6 inline-flex rounded-full bg-paper px-4 py-2 text-sm text-ink"
              >
                Begin
              </Link>
            </article>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
}
