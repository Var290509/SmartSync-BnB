"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function ExperimentActions({ id, status, slug }: { id: string; status: string; slug: string }) {
  const router = useRouter();
  const [message, setMessage] = useState("");

  async function setStatus(next: string) {
    const response = await fetch(`/api/experiments/${id}/publish`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: next }),
    });
    setMessage(response.ok ? `Now ${next}.` : "Could not update.");
    router.refresh();
  }

  async function remove() {
    if (!confirm("Delete this protocol and all anonymous sessions?")) return;
    await fetch(`/api/experiments/${id}`, { method: "DELETE" });
    router.push("/dashboard");
    router.refresh();
  }

  async function copyLink() {
    const url = `${window.location.origin}/run/${slug}`;
    await navigator.clipboard.writeText(url);
    setMessage("Link copied.");
  }

  return (
    <div className="mt-5 flex flex-wrap gap-2">
      {status !== "published" ? (
        <button type="button" onClick={() => setStatus("published")} className="rounded-full bg-teal px-4 py-2 text-sm text-ink">
          Publish
        </button>
      ) : (
        <button type="button" onClick={() => setStatus("paused")} className="rounded-full border border-ink/10 px-4 py-2 text-sm">
          Pause recruiting
        </button>
      )}
      <button type="button" onClick={copyLink} className="rounded-full border border-ink/10 px-4 py-2 text-sm">
        Copy link
      </button>
      <button type="button" onClick={remove} className="rounded-full px-4 py-2 text-sm text-coral">
        Delete
      </button>
      {message && <p className="w-full text-sm text-teal-2">{message}</p>}
    </div>
  );
}
