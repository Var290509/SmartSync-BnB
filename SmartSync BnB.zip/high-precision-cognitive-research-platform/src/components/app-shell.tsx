"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import type { ReactNode } from "react";
import { Wordmark } from "@/components/brand";
import type { ResearcherPublic } from "@/lib/types";

export function AppShell({
  researcher,
  children,
}: {
  researcher: ResearcherPublic;
  children: ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  }

  const links = [
    { href: "/dashboard", label: "Bench" },
    { href: "/experiments/new", label: "New protocol" },
    { href: "/studies", label: "Public board" },
  ];

  return (
    <div className="app-shell">
      <header className="sticky top-0 z-30 border-b border-ink/10 bg-[#efe9db]/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Wordmark inverted />
          <nav className="hidden items-center gap-6 text-sm md:flex">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={pathname === link.href ? "text-ink" : "text-ink/50 hover:text-ink"}
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-3 text-sm">
            <span className="hidden text-ink/50 sm:block">{researcher.name}</span>
            <button type="button" onClick={logout} className="rounded-full border border-ink/15 px-3 py-1.5">
              Sign out
            </button>
          </div>
        </div>
      </header>
      <div className="mx-auto w-full max-w-6xl px-6 py-10">{children}</div>
    </div>
  );
}
