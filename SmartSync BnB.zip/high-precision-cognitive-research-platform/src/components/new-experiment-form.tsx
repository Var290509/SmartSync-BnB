"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { TEMPLATE_LIST } from "@/lib/templates";
import { readJson } from "@/lib/utils";

export function NewExperimentForm() {
  const router = useRouter();
  const [templateKey, setTemplateKey] = useState("stroop");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setError("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/experiments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: form.get("title"),
        description: form.get("description"),
        irbNote: form.get("irbNote"),
        templateKey,
      }),
    });
    const payload = await readJson<{ experiment?: { id: string }; error?: string }>(response);
    setPending(false);
    if (!response.ok || !payload.experiment) {
      setError(payload.error || "Could not create experiment.");
      return;
    }
    router.push(`/experiments/${payload.experiment.id}/builder`);
  }

  return (
    <>
      <p className="font-mono text-xs uppercase tracking-[0.2em] text-teal-2">New protocol</p>
      <h1 className="mt-2 font-serif text-5xl">Choose a skeleton, then compose.</h1>
      <form onSubmit={onSubmit} className="mt-10 grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
        <div className="grid gap-3 sm:grid-cols-2">
          {TEMPLATE_LIST.map((template) => (
            <button
              key={template.key}
              type="button"
              onClick={() => setTemplateKey(template.key)}
              className={`rounded-[24px] border p-5 text-left ${
                templateKey === template.key ? "border-ink bg-white" : "border-transparent bg-white/50"
              }`}
            >
              <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-teal-2">{template.family}</p>
              <p className="mt-1 font-serif text-2xl">{template.name}</p>
              <p className="mt-2 text-sm text-ink/55">{template.blurb}</p>
            </button>
          ))}
        </div>
        <div className="rounded-[28px] bg-white p-6">
          <label className="block text-sm">
            Title
            <input
              name="title"
              required
              placeholder="Colour–word Stroop, Spring 2026"
              className="mt-1 w-full rounded-2xl border border-ink/10 px-4 py-3 outline-none"
            />
          </label>
          <label className="mt-4 block text-sm">
            Synopsis
            <textarea
              name="description"
              rows={4}
              className="mt-1 w-full rounded-2xl border border-ink/10 px-4 py-3 outline-none"
              placeholder="What is this study measuring?"
            />
          </label>
          <label className="mt-4 block text-sm">
            IRB / ethics note
            <textarea
              name="irbNote"
              rows={3}
              className="mt-1 w-full rounded-2xl border border-ink/10 px-4 py-3 outline-none"
              placeholder="Protocol ID, board, or exemption."
            />
          </label>
          {error && <p className="mt-3 text-sm text-coral">{error}</p>}
          <button
            type="submit"
            disabled={pending}
            className="mt-6 w-full rounded-full bg-ink py-3 text-sm text-paper disabled:opacity-60"
          >
            {pending ? "Creating…" : "Open in builder"}
          </button>
        </div>
      </form>
    </>
  );
}
