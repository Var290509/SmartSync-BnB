import Link from "next/link";

export function Mark({ className = "h-8 w-8" }: { className?: string }) {
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img src="/brand/mark.png" alt="" className={`${className} rounded-full`} />
  );
}

export function Wordmark({ inverted = false }: { inverted?: boolean }) {
  return (
    <Link href="/" className="flex items-center gap-2.5">
      <Mark className="h-9 w-9" />
      <span className={`text-[15px] tracking-[0.18em] uppercase ${inverted ? "text-ink" : "text-paper"}`}>
        Aperture
      </span>
    </Link>
  );
}
