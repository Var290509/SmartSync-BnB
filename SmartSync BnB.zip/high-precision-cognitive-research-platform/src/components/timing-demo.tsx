"use client";

import { useEffect, useRef, useState } from "react";

type Phase = "idle" | "wait" | "go" | "too-soon" | "result";

export function TimingDemo() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [rt, setRt] = useState<number | null>(null);
  const [onsetError, setOnsetError] = useState<number | null>(null);
  const [history, setHistory] = useState<number[]>([]);
  const onsetRef = useRef(0);
  const scheduledRef = useRef(0);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, []);

  function resetTimer() {
    if (timerRef.current) window.clearTimeout(timerRef.current);
  }

  function start() {
    resetTimer();
    setRt(null);
    setOnsetError(null);
    setPhase("wait");
    const delay = 800 + Math.random() * 1800;
    scheduledRef.current = performance.now() + delay;
    timerRef.current = window.setTimeout(() => {
      requestAnimationFrame(() => {
        onsetRef.current = performance.now();
        setOnsetError(onsetRef.current - scheduledRef.current);
        setPhase("go");
      });
    }, delay);
  }

  function onPointer() {
    if (phase === "idle" || phase === "result" || phase === "too-soon") {
      start();
      return;
    }
    if (phase === "wait") {
      resetTimer();
      setPhase("too-soon");
      return;
    }
    if (phase === "go") {
      const value = performance.now() - onsetRef.current;
      setRt(value);
      setHistory((prev) => [...prev.slice(-7), value]);
      setPhase("result");
    }
  }

  return (
    <div className="overflow-hidden rounded-[28px] border border-[var(--color-line)] bg-ink-2">
      <button
        type="button"
        onClick={onPointer}
        className="relative flex min-h-[340px] w-full flex-col items-center justify-center px-6 text-center"
      >
        {phase === "idle" && (
          <>
            <p className="font-mono text-xs uppercase tracking-[0.22em] text-teal">Live timing engine</p>
            <p className="mt-4 font-serif text-4xl text-paper">Click to arm</p>
            <p className="mt-3 max-w-sm text-sm text-mist">
              Stimulus onset is scheduled, then presented on the next animation frame. Response time uses{" "}
              <span className="font-mono text-paper">performance.now()</span>.
            </p>
          </>
        )}
        {phase === "wait" && (
          <>
            <div className="h-4 w-4 rounded-full bg-paper/30" />
            <p className="mt-6 font-mono text-xs uppercase tracking-[0.22em] text-mist">Hold… wait for teal</p>
          </>
        )}
        {phase === "go" && (
          <>
            <span className="pulse-ring absolute h-28 w-28 rounded-full border border-teal" />
            <span className="h-20 w-20 rounded-full bg-teal shadow-[0_0_60px_rgba(42,212,183,0.55)]" />
          </>
        )}
        {phase === "too-soon" && (
          <>
            <p className="font-serif text-3xl text-coral">Anticipation</p>
            <p className="mt-2 text-sm text-mist">Clicked before onset. Click to try again.</p>
          </>
        )}
        {phase === "result" && rt != null && (
          <>
            <p className="font-mono text-xs uppercase tracking-[0.22em] text-teal">Response time</p>
            <p className="mt-3 font-serif text-6xl tracking-tight text-paper">{rt.toFixed(1)}</p>
            <p className="mt-1 text-sm text-mist">milliseconds</p>
            {onsetError != null && (
              <p className="mt-4 font-mono text-xs text-gold">onset error {onsetError >= 0 ? "+" : ""}{onsetError.toFixed(2)} ms vs schedule</p>
            )}
            <p className="mt-6 text-sm text-mist">Click to run another trial</p>
          </>
        )}
      </button>
      {history.length > 0 && (
        <div className="flex items-end gap-1.5 border-t border-[var(--color-line)] px-5 py-4">
          {history.map((value, index) => (
            <div key={`${value}-${index}`} className="flex flex-1 flex-col items-center gap-1">
              <div
                className="w-full rounded-sm bg-teal/80"
                style={{ height: `${Math.min(64, value / 8)}px` }}
              />
              <span className="font-mono text-[10px] text-mist">{Math.round(value)}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
