"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { CalibrationResult, Demographics, ExperimentDefinition, RuntimeTrial } from "@/lib/types";
import { expandTrials } from "@/lib/experiment";
import { calibrateDisplay, waitAnimationFrames } from "@/lib/timing";
import { keyLabel, readJson } from "@/lib/utils";

type Phase =
  | "consent"
  | "demographics"
  | "calibrate"
  | "instructions"
  | "block"
  | "trial"
  | "complete"
  | "withdrawn";

type Display = {
  kind: RuntimeTrial["kind"] | "fixation" | "feedback" | "blank";
  content: string;
  color: string;
  fontSize: number;
  shape?: RuntimeTrial["shape"];
  feedback?: "correct" | "incorrect" | "timeout" | "hold";
};

export function Runner({
  code,
  definition,
  title,
  preview,
  estimatedMinutes,
}: {
  code: string;
  definition: ExperimentDefinition;
  title: string;
  preview: boolean;
  estimatedMinutes: number;
}) {
  const trials = useMemo(() => expandTrials(definition), [definition]);
  const [phase, setPhase] = useState<Phase>("consent");
  const [consent, setConsent] = useState(false);
  const [demo, setDemo] = useState<Demographics>({});
  const [calibration, setCalibration] = useState<CalibrationResult | null>(null);
  const [calibrating, setCalibrating] = useState(false);
  const [index, setIndex] = useState(0);
  const [display, setDisplay] = useState<Display>({
    kind: "blank",
    content: "",
    color: "#f4f1ea",
    fontSize: 64,
  });
  const [progress, setProgress] = useState("");
  const [anonymousId, setAnonymousId] = useState(preview ? "P-PREVIEW" : "");
  const [sessionId, setSessionId] = useState(preview ? "preview" : "");
  const [error, setError] = useState("");
  const running = useRef(false);
  const withdrawn = useRef(false);

  const trial = trials[index];

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        withdrawn.current = true;
        setPhase("withdrawn");
        void fetch(`/api/run/${code}/complete`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sessionId, preview, withdrawn: true }),
        });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [code, preview, sessionId]);

  async function startCalibration() {
    setCalibrating(true);
    const result = await calibrateDisplay(1100);
    setCalibration(result);
    setCalibrating(false);
  }

  async function beginSession() {
    setError("");
    const response = await fetch(`/api/run/${code}/start`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        preview,
        consent: true,
        calibration,
        demographics: definition.settings.collectDemographics ? demo : undefined,
        screen: { width: window.innerWidth, height: window.innerHeight },
        locale: navigator.language,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      }),
    });
    const payload = await readJson<{
      error?: string;
      sessionId?: string;
      anonymousId?: string;
    }>(response);
    if (!response.ok) {
      setError(payload.error || "Could not start session.");
      return;
    }
    setSessionId(payload.sessionId || "preview");
    setAnonymousId(payload.anonymousId || "P-PREVIEW");
    setPhase("instructions");
  }

  async function executeTrial(current: RuntimeTrial, trialIndex: number) {
    setIndex(trialIndex);
    setProgress(`${trialIndex + 1} / ${trials.length}`);
    setDisplay({ kind: "blank", content: "", color: current.color, fontSize: current.fontSize });
    if (current.fixationMs > 0) {
      setDisplay({ kind: "fixation", content: "+", color: "#f4f1ea", fontSize: 48 });
      await waitAnimationFrames(current.fixationMs);
    }
    if (current.soaJitterMs) {
      const extra =
        current.soaJitterMs[0] + Math.random() * (current.soaJitterMs[1] - current.soaJitterMs[0]);
      await waitAnimationFrames(extra);
    }
    const scheduled = performance.now();
    await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
    setDisplay({
      kind: current.kind,
      content: current.content,
      color: current.color,
      fontSize: current.fontSize,
      shape: current.shape,
    });
    const actual = performance.now();
    const result = await readResponse(current, actual);
    if (withdrawn.current) return;

    const isCorrect = scoreTrial(current, result);
    if (current.feedback || (current.blockType === "practice" && definition.settings.feedbackPracticeOnly)) {
      setDisplay({
        kind: "feedback",
        content: result.timeout ? "Too slow" : isCorrect ? "Correct" : "Incorrect",
        color: result.timeout ? "#e0b567" : isCorrect ? "#2ad4b7" : "#ff6b5a",
        fontSize: 36,
        feedback: result.timeout ? "timeout" : isCorrect ? "correct" : "incorrect",
      });
      await waitAnimationFrames(500);
    }

    await fetch(`/api/run/${code}/response`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        sessionId,
        preview,
        blockId: current.blockId,
        trialId: current.id,
        trialIndex,
        stimulusLabel: current.content || current.shape || current.kind,
        condition: current.condition,
        correctKey: current.correctKey,
        responseKey: result.key,
        isCorrect,
        isTimeout: result.timeout,
        rtMs: result.rt,
        scheduledOnsetMs: scheduled,
        actualOnsetMs: actual,
        onsetErrorMs: actual - scheduled,
      }),
    });

    setDisplay({ kind: "blank", content: "", color: current.color, fontSize: current.fontSize });
    await waitAnimationFrames(current.isiMs + definition.settings.interTrialInterval);
  }

  function continueBlock() {
    const start = index;
    if (running.current) return;
    void (async () => {
      running.current = true;
      setPhase("trial");
      for (let i = start; i < trials.length; i += 1) {
        if (withdrawn.current) break;
        const current = trials[i];
        if (i !== start && current.blockId !== trials[start].blockId) {
          running.current = false;
          setIndex(i);
          setPhase("block");
          return;
        }
        await executeTrial(current, i);
      }
      running.current = false;
      if (!withdrawn.current) {
        await fetch(`/api/run/${code}/complete`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sessionId, preview }),
        });
        setPhase("complete");
      }
    })();
  }

  return (
    <div className="stimulus-stage flex min-h-screen flex-col">
      <div className="flex items-center justify-between px-5 py-4 font-mono text-[11px] uppercase tracking-[0.16em] text-white/30">
        <span>{preview ? "Preview · not recorded" : title}</span>
        <span>{progress || `${estimatedMinutes} min`}</span>
      </div>
      <div className="flex flex-1 flex-col items-center justify-center px-6">
        {phase === "consent" && (
          <div className="w-full max-w-xl text-center">
            <p className="font-mono text-xs text-teal">{code}</p>
            <h1 className="mt-3 font-serif text-4xl text-paper">{title}</h1>
            <p className="mt-4 text-left text-sm leading-relaxed text-white/70">{definition.consent.body}</p>
            <label className="mt-6 flex items-start gap-3 text-left text-sm text-paper">
              <input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} />
              I consent to take part. I understand I can press Escape to withdraw.
            </label>
            <button
              type="button"
              disabled={!consent}
              onClick={() => setPhase(definition.settings.collectDemographics ? "demographics" : "calibrate")}
              className="mt-6 rounded-full bg-teal px-6 py-3 text-sm text-ink disabled:opacity-40"
            >
              Continue
            </button>
          </div>
        )}

        {phase === "demographics" && (
          <form
            className="w-full max-w-md space-y-4 text-left"
            onSubmit={(event) => {
              event.preventDefault();
              setPhase("calibrate");
            }}
          >
            <h2 className="font-serif text-3xl text-paper">Optional background</h2>
            <p className="text-sm text-white/50">Skip any field. Nothing identifying is stored.</p>
            <label className="block text-sm text-paper">
              Age range
              <select
                className="mt-1 w-full rounded-xl bg-white/10 px-3 py-2"
                onChange={(event) => setDemo((current) => ({ ...current, ageRange: event.target.value }))}
              >
                <option value="">Prefer not to say</option>
                <option>18–24</option>
                <option>25–34</option>
                <option>35–44</option>
                <option>45–54</option>
                <option>55+</option>
              </select>
            </label>
            <label className="block text-sm text-paper">
              Handedness
              <select
                className="mt-1 w-full rounded-xl bg-white/10 px-3 py-2"
                onChange={(event) => setDemo((current) => ({ ...current, handedness: event.target.value }))}
              >
                <option value="">Prefer not to say</option>
                <option>Right</option>
                <option>Left</option>
                <option>Ambidextrous</option>
              </select>
            </label>
            <button type="submit" className="rounded-full bg-teal px-6 py-3 text-sm text-ink">
              Continue
            </button>
          </form>
        )}

        {phase === "calibrate" && (
          <div className="max-w-md text-center">
            <h2 className="font-serif text-3xl text-paper">Display calibration</h2>
            <p className="mt-3 text-sm text-white/60">
              We sample animation-frame intervals to estimate refresh rate and jitter. Keep this tab focused.
            </p>
            {calibration ? (
              <div className="mt-6 font-mono text-sm text-teal">
                {calibration.refreshHz.toFixed(1)} Hz · jitter {calibration.frameJitterMs.toFixed(2)} ms ·{" "}
                {calibration.quality}
              </div>
            ) : (
              <button
                type="button"
                onClick={startCalibration}
                disabled={calibrating}
                className="mt-6 rounded-full bg-paper px-6 py-3 text-sm text-ink"
              >
                {calibrating ? "Sampling frames…" : "Calibrate"}
              </button>
            )}
            {calibration && (
              <button
                type="button"
                onClick={beginSession}
                className="mt-6 block w-full rounded-full bg-teal px-6 py-3 text-sm text-ink"
              >
                Start experiment
              </button>
            )}
            {error && <p className="mt-3 text-sm text-coral">{error}</p>}
          </div>
        )}

        {phase === "instructions" && (
          <div className="max-w-xl text-center">
            <h2 className="font-serif text-3xl text-paper">Instructions</h2>
            <ol className="mt-5 space-y-3 text-left text-sm text-white/70">
              {definition.instructions.map((line) => (
                <li key={line}>{line}</li>
              ))}
            </ol>
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              {definition.keyLegend.map((item) => (
                <span key={item.key} className="rounded-full bg-white/10 px-3 py-1 font-mono text-xs text-paper">
                  {keyLabel(item.key)} · {item.meaning}
                </span>
              ))}
            </div>
            <button
              type="button"
              onClick={() => {
                setIndex(0);
                setPhase("block");
              }}
              className="mt-8 rounded-full bg-teal px-6 py-3 text-sm text-ink"
            >
              I am ready
            </button>
          </div>
        )}

        {phase === "block" && trial && (
          <div className="max-w-lg text-center">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-gold">{trial.blockType}</p>
            <h2 className="mt-3 font-serif text-4xl text-paper">{trial.blockName}</h2>
            <p className="mt-4 text-white/65">
              {definition.blocks.find((block) => block.id === trial.blockId)?.instructions}
            </p>
            <button type="button" onClick={continueBlock} className="mt-8 rounded-full bg-paper px-6 py-3 text-sm text-ink">
              Begin block
            </button>
          </div>
        )}

        {phase === "trial" && <StimulusView display={display} />}

        {phase === "complete" && (
          <div className="max-w-lg text-center">
            <p className="font-mono text-xs text-teal">Session stored</p>
            <h2 className="mt-3 font-serif text-4xl text-paper">Thank you.</h2>
            <p className="mt-4 text-white/65">{definition.debrief}</p>
            <p className="mt-6 font-mono text-lg text-gold">{anonymousId}</p>
            <p className="mt-1 text-xs text-white/40">Keep this anonymous code if you need to contact the researcher.</p>
          </div>
        )}

        {phase === "withdrawn" && (
          <div className="max-w-lg text-center">
            <h2 className="font-serif text-4xl text-paper">Withdrawn</h2>
            <p className="mt-4 text-white/65">
              The session is marked withdrawn. No further trials will be collected.
            </p>
          </div>
        )}
      </div>
      <p className="px-5 py-4 text-center font-mono text-[10px] uppercase tracking-[0.18em] text-white/25">
        Escape withdraws · {preview ? "preview mode" : "anonymous session"}
      </p>
    </div>
  );
}

function StimulusView({ display }: { display: Display }) {
  if (display.kind === "blank") return <div className="h-32" />;
  if (display.kind === "fixation") {
    return <p className="text-5xl text-paper">+</p>;
  }
  if (display.kind === "shape" || display.kind === "gonogo") {
    const radius = display.shape === "square" ? "rounded-md" : "rounded-full";
    return (
      <div className="flex flex-col items-center gap-4">
        <div className={`h-24 w-24 ${radius}`} style={{ background: display.color }} />
        {display.content && <p className="font-serif text-4xl text-paper">{display.content}</p>}
      </div>
    );
  }
  return (
    <p className="font-serif tracking-wide" style={{ color: display.color, fontSize: display.fontSize }}>
      {display.content}
    </p>
  );
}

function scoreTrial(trial: RuntimeTrial, result: { key: string | null; timeout: boolean }) {
  if (trial.nogo || trial.correctKey == null) {
    return result.timeout || result.key == null;
  }
  if (result.timeout || !result.key) return false;
  return result.key.toLowerCase() === trial.correctKey.toLowerCase() || result.key === trial.correctKey;
}

function readResponse(trial: RuntimeTrial, onset: number) {
  return new Promise<{ key: string | null; rt: number | null; timeout: boolean }>((resolve) => {
    let settled = false;
    const keys = trial.responseKeys;
    const finish = (payload: { key: string | null; rt: number | null; timeout: boolean }) => {
      if (settled) return;
      settled = true;
      window.removeEventListener("keydown", onKey);
      window.clearTimeout(timer);
      resolve(payload);
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") return;
      const hit = keys.some((key) => key === event.key || key.toLowerCase() === event.key.toLowerCase());
      if (!hit) return;
      event.preventDefault();
      finish({ key: event.key, rt: performance.now() - onset, timeout: false });
    };
    window.addEventListener("keydown", onKey);
    const timer = window.setTimeout(() => finish({ key: null, rt: null, timeout: true }), trial.timeoutMs);
  });
}
