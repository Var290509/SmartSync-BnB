"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { readJson } from "@/lib/utils";

export function LoginForm() {
  const router = useRouter();
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setError("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: form.get("email"),
        password: form.get("password"),
      }),
    });
    const payload = await readJson<{ error?: string }>(response);
    setPending(false);
    if (!response.ok) {
      setError(payload.error || "Could not sign in.");
      return;
    }
    router.push("/dashboard");
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <label className="block text-sm">
        Email
        <input
          name="email"
          type="email"
          required
          defaultValue="iris.patel@aperture.lab"
          className="mt-1 w-full rounded-2xl border border-ink/10 bg-white px-4 py-3 text-ink outline-none focus:border-teal-2"
        />
      </label>
      <label className="block text-sm">
        Password
        <input
          name="password"
          type="password"
          required
          defaultValue="research2026"
          className="mt-1 w-full rounded-2xl border border-ink/10 bg-white px-4 py-3 text-ink outline-none focus:border-teal-2"
        />
      </label>
      {error && <p className="text-sm text-coral">{error}</p>}
      <button
        type="submit"
        disabled={pending}
        className="w-full rounded-full bg-ink py-3 text-sm text-paper disabled:opacity-60"
      >
        {pending ? "Signing in…" : "Enter the lab bench"}
      </button>
    </form>
  );
}

export function RegisterForm() {
  const router = useRouter();
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setError("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: form.get("name"),
        email: form.get("email"),
        institution: form.get("institution"),
        password: form.get("password"),
      }),
    });
    const payload = await readJson<{ error?: string }>(response);
    setPending(false);
    if (!response.ok) {
      setError(payload.error || "Could not create account.");
      return;
    }
    router.push("/dashboard");
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <label className="block text-sm">
        Name
        <input
          name="name"
          required
          className="mt-1 w-full rounded-2xl border border-ink/10 bg-white px-4 py-3 text-ink outline-none focus:border-teal-2"
        />
      </label>
      <label className="block text-sm">
        Email
        <input
          name="email"
          type="email"
          required
          className="mt-1 w-full rounded-2xl border border-ink/10 bg-white px-4 py-3 text-ink outline-none focus:border-teal-2"
        />
      </label>
      <label className="block text-sm">
        Institution
        <input
          name="institution"
          className="mt-1 w-full rounded-2xl border border-ink/10 bg-white px-4 py-3 text-ink outline-none focus:border-teal-2"
        />
      </label>
      <label className="block text-sm">
        Password
        <input
          name="password"
          type="password"
          required
          minLength={8}
          className="mt-1 w-full rounded-2xl border border-ink/10 bg-white px-4 py-3 text-ink outline-none focus:border-teal-2"
        />
      </label>
      {error && <p className="text-sm text-coral">{error}</p>}
      <button
        type="submit"
        disabled={pending}
        className="w-full rounded-full bg-ink py-3 text-sm text-paper disabled:opacity-60"
      >
        {pending ? "Creating…" : "Create researcher account"}
      </button>
    </form>
  );
}
