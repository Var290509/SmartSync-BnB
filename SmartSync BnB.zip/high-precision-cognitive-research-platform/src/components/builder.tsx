"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { blankBlock, blankTrial, countTrials } from "@/lib/experiment";
import type { BlockDefinition, ExperimentDefinition, StimulusKind, TrialDefinition } from "@/lib/types";
import { keyLabel } from "@/lib/utils";

type ExperimentRow = {
  id: string;
  title: string;
  description: string;
  slug: string;
  status: string;
  irbNote: string | null;
  definition: ExperimentDefinition;
};

const KINDS: StimulusKind[] = ["text", "stroop", "flanker", "gonogo", "letter", "shape", "fixation", "blank"];

export function Builder({ experiment }: { experiment: ExperimentRow }) {
  const [title, setTitle] = useState(experiment.title);
  const [description, setDescription] = useState(experiment.description);
  const [irbNote, setIrbNote] = useState(experiment.irbNote ?? "");
  const [definition, setDefinition] = useState<ExperimentDefinition>(experiment.definition);
  const [blockId, setBlockId] = useState(experiment.definition.blocks[0]?.id ?? "");
  const [trialId, setTrialId] = useState(experiment.definition.blocks[0]?.trials[0]?.id ?? "");
  const [status, setStatus] = useState("");
  const [saving, setSaving] = useState(false);

  const block = definition.blocks.find((item) => item.id === blockId) ?? definition.blocks[0];
  const trial = block?.trials.find((item) => item.id === trialId) ?? block?.trials[0];
  const trialCount = useMemo(() => countTrials(definition), [definition]);

  function patchDefinition(patch: Partial<ExperimentDefinition>) {
    setDefinition((current) => ({ ...current, ...patch }));
  }

  function patchBlock(id: string, patch: Partial<BlockDefinition>) {
    setDefinition((current) => ({
      ...current,
      blocks: current.blocks.map((item) => (item.id === id ? { ...item, ...patch } : item)),
    }));
  }

  function patchTrial(targetBlock: string, targetTrial: string, patch: Partial<TrialDefinition>) {
    setDefinition((current) => ({
      ...current,
      blocks: current.blocks.map((item) =>
        item.id === targetBlock
          ? {
              ...item,
              trials: item.trials.map((row) => (row.id === targetTrial ? { ...row, ...patch } : row)),
            }
          : item,
      ),
    }));
  }

  function moveTrial(index: number, direction: -1 | 1) {
    if (!block) return;
    const next = index + direction;
    if (next < 0 || next >= block.trials.length) return;
    const trials = [...block.trials];
    [trials[index], trials[next]] = [trials[next], trials[index]];
    patchBlock(block.id, { trials });
  }

  async function save() {
    setSaving(true);
    setStatus("");
    const response = await fetch(`/api/experiments/${experiment.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, description, irbNote, definition }),
    });
    setSaving(false);
    setStatus(response.ok ? "Protocol saved." : "Save failed.");
  }

  async function publish(nextStatus: "published" | "paused" | "draft") {
    await save();
    const response = await fetch(`/api/experiments/${experiment.id}/publish`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: nextStatus }),
    });
    setStatus(response.ok ? `Status → ${nextStatus}` : "Could not update status.");
  }

  return (
    <div className="app-shell min-h-screen">
      <div className="border-b border-ink/10 bg-[#efe9db]/90 px-6 py-4">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3">
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-teal-2">
              {experiment.slug} · {trialCount} trials
            </p>
            <input
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              className="bg-transparent font-serif text-3xl outline-none"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <Link href={`/experiments/${experiment.id}`} className="rounded-full border border-ink/10 px-4 py-2 text-sm">
              Overview
            </Link>
            <Link
              href={`/run/${experiment.slug}?preview=1`}
              className="rounded-full border border-ink/10 px-4 py-2 text-sm"
            >
              Preview
            </Link>
            <button type="button" onClick={save} disabled={saving} className="rounded-full bg-ink px-4 py-2 text-sm text-paper">
              {saving ? "Saving…" : "Save"}
            </button>
            <button type="button" onClick={() => publish("published")} className="rounded-full bg-teal px-4 py-2 text-sm text-ink">
              Publish
            </button>
          </div>
        </div>
        {status && <p className="mx-auto mt-2 max-w-7xl font-mono text-xs text-teal-2">{status}</p>}
      </div>

      <div className="mx-auto grid max-w-7xl gap-6 px-6 py-8 lg:grid-cols-[240px_1fr_300px]">
        <aside className="space-y-3">
          <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink/40">Blocks</p>
          {definition.blocks.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setBlockId(item.id);
                setTrialId(item.trials[0]?.id ?? "");
              }}
              className={`w-full rounded-2xl p-4 text-left ${item.id === block?.id ? "bg-ink text-paper" : "bg-white"}`}
            >
              <p className="font-serif text-xl">{item.name}</p>
              <p className={`mt-1 text-xs ${item.id === block?.id ? "text-paper/60" : "text-ink/45"}`}>
                {item.type} · {item.trials.length} trials · {item.randomization}
              </p>
            </button>
          ))}
          <button
            type="button"
            onClick={() => {
              const created = blankBlock();
              setDefinition((current) => ({ ...current, blocks: [...current.blocks, created] }));
              setBlockId(created.id);
              setTrialId(created.trials[0].id);
            }}
            className="w-full rounded-2xl border border-dashed border-ink/20 py-3 text-sm"
          >
            Add block
          </button>
        </aside>

        <section className="rounded-[28px] bg-white p-5">
          {block && (
            <>
              <div className="grid gap-3 md:grid-cols-2">
                <label className="text-sm">
                  Block name
                  <input
                    value={block.name}
                    onChange={(event) => patchBlock(block.id, { name: event.target.value })}
                    className="mt-1 w-full rounded-xl border border-ink/10 px-3 py-2"
                  />
                </label>
                <label className="text-sm">
                  Type
                  <select
                    value={block.type}
                    onChange={(event) => patchBlock(block.id, { type: event.target.value as BlockDefinition["type"] })}
                    className="mt-1 w-full rounded-xl border border-ink/10 px-3 py-2"
                  >
                    <option value="practice">Practice</option>
                    <option value="experimental">Experimental</option>
                  </select>
                </label>
                <label className="text-sm">
                  Randomization
                  <select
                    value={block.randomization}
                    onChange={(event) =>
                      patchBlock(block.id, { randomization: event.target.value as BlockDefinition["randomization"] })
                    }
                    className="mt-1 w-full rounded-xl border border-ink/10 px-3 py-2"
                  >
                    <option value="none">Fixed order</option>
                    <option value="shuffle">Shuffle trials</option>
                  </select>
                </label>
                <label className="text-sm">
                  Repeat
                  <input
                    type="number"
                    min={1}
                    value={block.repeat}
                    onChange={(event) => patchBlock(block.id, { repeat: Number(event.target.value) || 1 })}
                    className="mt-1 w-full rounded-xl border border-ink/10 px-3 py-2"
                  />
                </label>
              </div>
              <label className="mt-3 block text-sm">
                Block instructions
                <textarea
                  value={block.instructions}
                  onChange={(event) => patchBlock(block.id, { instructions: event.target.value })}
                  className="mt-1 w-full rounded-xl border border-ink/10 px-3 py-2"
                  rows={2}
                />
              </label>
              <div className="mt-5 space-y-2">
                {block.trials.map((item, index) => (
                  <div
                    key={item.id}
                    className={`flex items-center gap-3 rounded-2xl border px-3 py-3 ${
                      item.id === trial?.id ? "border-ink bg-[#f7f1e4]" : "border-ink/10"
                    }`}
                  >
                    <button type="button" className="flex-1 text-left" onClick={() => setTrialId(item.id)}>
                      <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink/40">
                        {item.kind} · {item.condition || "—"}
                      </p>
                      <p className="font-serif text-xl" style={{ color: item.kind === "stroop" ? item.color : undefined }}>
                        {item.content || item.shape || "blank"}
                      </p>
                      <p className="text-xs text-ink/45">
                        {item.fixationMs}ms + {item.timeoutMs}ms · keys {item.responseKeys.map(keyLabel).join(" ")}
                      </p>
                    </button>
                    <div className="flex flex-col gap-1">
                      <button type="button" onClick={() => moveTrial(index, -1)} className="text-xs">
                        ↑
                      </button>
                      <button type="button" onClick={() => moveTrial(index, 1)} className="text-xs">
                        ↓
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <button
                type="button"
                onClick={() => {
                  const created = blankTrial({ kind: trial?.kind ?? "text" });
                  patchBlock(block.id, { trials: [...block.trials, created] });
                  setTrialId(created.id);
                }}
                className="mt-4 rounded-full border border-ink/15 px-4 py-2 text-sm"
              >
                Add trial
              </button>
            </>
          )}
        </section>

        <aside className="space-y-4">
          {trial && block && (
            <div className="rounded-[28px] bg-white p-5">
              <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink/40">Inspector</p>
              <label className="mt-3 block text-sm">
                Kind
                <select
                  value={trial.kind}
                  onChange={(event) => patchTrial(block.id, trial.id, { kind: event.target.value as StimulusKind })}
                  className="mt-1 w-full rounded-xl border border-ink/10 px-3 py-2"
                >
                  {KINDS.map((kind) => (
                    <option key={kind} value={kind}>
                      {kind}
                    </option>
                  ))}
                </select>
              </label>
              <label className="mt-3 block text-sm">
                Content
                <input
                  value={trial.content}
                  onChange={(event) => patchTrial(block.id, trial.id, { content: event.target.value })}
                  className="mt-1 w-full rounded-xl border border-ink/10 px-3 py-2"
                />
              </label>
              <label className="mt-3 block text-sm">
                Colour
                <input
                  value={trial.color}
                  onChange={(event) => patchTrial(block.id, trial.id, { color: event.target.value })}
                  className="mt-1 w-full rounded-xl border border-ink/10 px-3 py-2"
                />
              </label>
              <label className="mt-3 block text-sm">
                Condition label
                <input
                  value={trial.condition ?? ""}
                  onChange={(event) => patchTrial(block.id, trial.id, { condition: event.target.value })}
                  className="mt-1 w-full rounded-xl border border-ink/10 px-3 py-2"
                />
              </label>
              <div className="mt-3 grid grid-cols-3 gap-2 text-sm">
                <label>
                  Fixation
                  <input
                    type="number"
                    value={trial.fixationMs}
                    onChange={(event) => patchTrial(block.id, trial.id, { fixationMs: Number(event.target.value) })}
                    className="mt-1 w-full rounded-xl border border-ink/10 px-2 py-2"
                  />
                </label>
                <label>
                  Timeout
                  <input
                    type="number"
                    value={trial.timeoutMs}
                    onChange={(event) => patchTrial(block.id, trial.id, { timeoutMs: Number(event.target.value) })}
                    className="mt-1 w-full rounded-xl border border-ink/10 px-2 py-2"
                  />
                </label>
                <label>
                  ISI
                  <input
                    type="number"
                    value={trial.isiMs}
                    onChange={(event) => patchTrial(block.id, trial.id, { isiMs: Number(event.target.value) })}
                    className="mt-1 w-full rounded-xl border border-ink/10 px-2 py-2"
                  />
                </label>
              </div>
              <label className="mt-3 block text-sm">
                Response keys (comma)
                <input
                  value={trial.responseKeys.join(",")}
                  onChange={(event) =>
                    patchTrial(block.id, trial.id, {
                      responseKeys: event.target.value.split(",").map((value) => value.trim()).filter(Boolean),
                    })
                  }
                  className="mt-1 w-full rounded-xl border border-ink/10 px-3 py-2"
                />
              </label>
              <label className="mt-3 block text-sm">
                Correct key (blank = withhold)
                <input
                  value={trial.correctKey ?? ""}
                  onChange={(event) =>
                    patchTrial(block.id, trial.id, { correctKey: event.target.value === "" ? null : event.target.value })
                  }
                  className="mt-1 w-full rounded-xl border border-ink/10 px-3 py-2"
                />
              </label>
              <label className="mt-3 flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={Boolean(trial.nogo)}
                  onChange={(event) => patchTrial(block.id, trial.id, { nogo: event.target.checked })}
                />
                No-go / withhold trial
              </label>
              <button
                type="button"
                onClick={() => {
                  const next = block.trials.filter((item) => item.id !== trial.id);
                  patchBlock(block.id, { trials: next });
                  setTrialId(next[0]?.id ?? "");
                }}
                className="mt-4 text-sm text-coral"
              >
                Delete trial
              </button>
            </div>
          )}

          <div className="rounded-[28px] bg-white p-5">
            <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink/40">Consent & keys</p>
            <textarea
              value={definition.consent.body}
              onChange={(event) =>
                patchDefinition({ consent: { ...definition.consent, body: event.target.value } })
              }
              rows={5}
              className="mt-3 w-full rounded-xl border border-ink/10 px-3 py-2 text-sm"
            />
            <textarea
              value={description}
              onChange={(event) => setDescription(event.target.value)}
              rows={3}
              className="mt-3 w-full rounded-xl border border-ink/10 px-3 py-2 text-sm"
              placeholder="Public synopsis"
            />
            <textarea
              value={irbNote}
              onChange={(event) => setIrbNote(event.target.value)}
              rows={2}
              className="mt-3 w-full rounded-xl border border-ink/10 px-3 py-2 text-sm"
              placeholder="IRB note"
            />
            <label className="mt-3 flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={definition.settings.collectDemographics}
                onChange={(event) =>
                  patchDefinition({
                    settings: { ...definition.settings, collectDemographics: event.target.checked },
                  })
                }
              />
              Collect coarse demographics
            </label>
          </div>
        </aside>
      </div>
    </div>
  );
}
