import Link from "next/link";
import { Wordmark } from "@/components/brand";
import type { ResearcherPublic } from "@/lib/types";

export function MarketingNav({ researcher }: { researcher: ResearcherPublic | null }) {
  return (
    <header className="relative z-20 mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-6">
      <Wordmark />
      <nav className="hidden items-center gap-8 text-sm text-mist md:flex">
        <Link href="/#engine" className="hover:text-paper">
          Timing engine
        </Link>
        <Link href="/#builder" className="hover:text-paper">
          Builder
        </Link>
        <Link href="/studies" className="hover:text-paper">
          Open studies
        </Link>
        <Link href="/docs" className="hover:text-paper">
          Methods
        </Link>
      </nav>
      <div className="flex items-center gap-3">
        {researcher ? (
          <Link
            href="/dashboard"
            className="rounded-full bg-teal px-4 py-2 text-sm font-medium text-ink hover:brightness-110"
          >
            Lab bench
          </Link>
        ) : (
          <>
            <Link href="/login" className="hidden text-sm text-mist hover:text-paper sm:block">
              Sign in
            </Link>
            <Link
              href="/register"
              className="rounded-full bg-paper px-4 py-2 text-sm font-medium text-ink hover:bg-white"
            >
              Open a lab
            </Link>
          </>
        )}
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-[var(--color-line)] px-6 py-10 text-sm text-mist">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="font-serif text-2xl text-paper">Aperture</p>
          <p className="mt-2 max-w-sm text-mist">
            High-precision behavioural experiments in the browser. Anonymous by default. Built for cognitive science.
          </p>
        </div>
        <div className="flex flex-wrap gap-6">
          <Link href="/privacy">Privacy</Link>
          <Link href="/ethics">Ethics & IRB</Link>
          <Link href="/docs">Timing methods</Link>
          <Link href="/studies">Open studies</Link>
        </div>
      </div>
    </footer>
  );
}
